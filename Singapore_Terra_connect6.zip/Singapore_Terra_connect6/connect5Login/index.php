<?php
/**
 * Login page with OTP (One-Time Password) email verification.
 *
 * Flow:
 *   1. User submits username + password.
 *   2. Credentials are checked against `users` (via prepared statement).
 *   3. On success, a 6-digit OTP is generated, stored server-side in the
 *      session, and emailed to users.user_email.
 *   4. User is shown an OTP entry form. On correct + non-expired OTP,
 *      the ORIGINAL post-login business logic runs (conference number
 *      assignment, user_live / user_log inserts, session vars, redirect).
 *
 * SECURITY NOTES (please read):
 *   - All queries now use mysqli prepared statements (bind_param) instead
 *     of string concatenation. The original file concatenated $_POST values
 *     directly into SQL, which is a SQL injection vulnerability.
 *   - Passwords are still compared as plain text against `user_password`
 *     to match your existing schema. This is NOT secure. As a follow-up,
 *     I'd strongly recommend migrating to password_hash()/password_verify()
 *     and re-hashing passwords on next login.
 *   - OTP is stored in $_SESSION (server-side, not visible to the client),
 *     expires after 5 minutes, and allows a max of 5 verification attempts.
 */

$start_time = microtime(true);
require_once("db_connect.php");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// ---------------------------------------------------------------------
// Fetch "star of the month" toggle
// ---------------------------------------------------------------------
$star_month = 0;
if ($stmt = mysqli_prepare($conn, "SELECT star_month FROM features_settings")) {
    mysqli_stmt_execute($stmt);
    $rslt_rs = mysqli_stmt_get_result($stmt);
    if ($rslt_rs && mysqli_num_rows($rslt_rs) >= 1) {
        while ($row = mysqli_fetch_assoc($rslt_rs)) {
            $star_month = $row["star_month"];
        }
    }
    mysqli_stmt_close($stmt);
}

$login_errorr = "";
$otp_stage    = false; // true => render the OTP entry form instead of the login form

// ---------------------------------------------------------------------
// Helper: send a 6-digit OTP by email
// ---------------------------------------------------------------------
function sendOtpEmail($toEmail, $otp)
{
    $subject = "Your Connect6.0 Login OTP";
    $message = "Your one-time password (OTP) is: {$otp}\n\n"
             . "This code expires in 5 minutes. If you did not attempt to log in, "
             . "please ignore this email or contact your administrator.";
    $headers = "From: no-reply@yourdomain.com\r\n"
             . "Content-Type: text/plain; charset=UTF-8\r\n";

    // --- Default: PHP's built-in mail() function ---
    return @mail($toEmail, $subject, $message, $headers);

    /*
    // --- Alternative: PHPMailer with SMTP (recommended for production) ---
    // composer require phpmailer/phpmailer
    require 'vendor/autoload.php';
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.yourprovider.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'your_smtp_username';
        $mail->Password   = 'your_smtp_password';
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('no-reply@yourdomain.com', 'Connect6.0');
        $mail->addAddress($toEmail);
        $mail->Subject = $subject;
        $mail->Body    = $message;

        return $mail->send();
    } catch (Exception $e) {
        return false;
    }
    */
}

// ---------------------------------------------------------------------
// Helper: run the ORIGINAL post-login business logic once OTP is verified.
// This mirrors the logic that used to run immediately after password check.
// Ends in a header() redirect + exit.
// ---------------------------------------------------------------------
function completeLogin($conn, $username, $password)
{
    // Free up any conference slot currently tied to this user's agent extension
    $stmt = mysqli_prepare($conn, "SELECT agent FROM user_conference WHERE agent = (SELECT extension_id FROM users WHERE user_id = ?)");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $resd = mysqli_stmt_get_result($stmt);
    if ($resd && mysqli_num_rows($resd) >= 1) {
        $rowd = mysqli_fetch_assoc($resd);
        $agd  = $rowd['agent'];
        $s2 = mysqli_prepare($conn, "UPDATE user_conference SET agent = '', status = '0' WHERE agent = ?");
        mysqli_stmt_bind_param($s2, "s", $agd);
        mysqli_stmt_execute($s2);
    }
    mysqli_query($conn, "UPDATE user_conference SET status = '0' WHERE agent = ''");

    $stmt_con = mysqli_prepare($conn, "SELECT conference_number FROM user_conference WHERE status = '0' ORDER BY id ASC LIMIT 1");
    mysqli_stmt_execute($stmt_con);
    $row_con = mysqli_stmt_get_result($stmt_con)->fetch_row();
    $user_conference_number = $row_con[0] ?? null;

    $stmt = mysqli_prepare($conn, "UPDATE users SET conference_number = ? WHERE user_id = ? AND user_level = 'D4'");
    mysqli_stmt_bind_param($stmt, "ss", $user_conference_number, $username);
    mysqli_stmt_execute($stmt);

    $stmt = mysqli_prepare($conn, "UPDATE user_conference SET status = '1' WHERE conference_number = ?");
    mysqli_stmt_bind_param($stmt, "s", $user_conference_number);
    mysqli_stmt_execute($stmt);

    $stmt = mysqli_prepare($conn, "SELECT user_level, extension_id, conference_number, Campaign, work_type FROM users WHERE user_id = ? AND user_password = ?");
    mysqli_stmt_bind_param($stmt, "ss", $username, $password);
    mysqli_stmt_execute($stmt);
    $rslt_rs = mysqli_stmt_get_result($stmt);
    $row_rs  = mysqli_fetch_row($rslt_rs);

    if ($rslt_rs && mysqli_num_rows($rslt_rs) > 0) {
        $_SESSION['user_level'] = $row_rs[0];
        $userExtension    = $row_rs[1];
        $Conf_Number      = $row_rs[2];
        $userWorkType1    = $row_rs[3];
        $user_work_type   = $row_rs[4];

        $stmt = mysqli_prepare($conn, "UPDATE user_conference SET agent = ? WHERE conference_number = ?");
        mysqli_stmt_bind_param($stmt, "ss", $userExtension, $user_conference_number);
        mysqli_stmt_execute($stmt);

        if ($row_rs[0] == 'D4') {
            $_SESSION['AgentUserName'] = $username;
            $_SESSION['AgentPassword'] = $password;
            $_SESSION['extension']     = $userExtension;
            $_SESSION['campaign']      = $userWorkType1;
            $_SESSION['conf_num']      = $Conf_Number;

            $stmt = mysqli_prepare($conn, "SELECT user_group FROM campaign WHERE campaign_id = ?");
            mysqli_stmt_bind_param($stmt, "s", $userWorkType1);
            mysqli_stmt_execute($stmt);
            $camp_rows = mysqli_stmt_get_result($stmt)->fetch_assoc();
            $_SESSION['User_Group'] = $camp_rows['user_group'] ?? null;

            $stmt = mysqli_prepare($conn, "SELECT id FROM user_live WHERE user = ?");
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            $row_rs1 = mysqli_stmt_get_result($stmt)->fetch_row();

            if (empty($row_rs1)) {
                $date = date("Y-m-d H:i:s");

                $stmt = mysqli_prepare($conn, "INSERT INTO user_live
                    (created_date, user, status, extension, callstatus, campaign, confnum, auto_flag, waittime, timer, pause_flag, ringroup)
                    VALUES (?, ?, 'PAUSED', ?, 'IDLE', ?, ?, '0', ?, '0', '0', '')");
                mysqli_stmt_bind_param($stmt, "ssssss", $date, $username, $userExtension, $userWorkType1, $Conf_Number, $date);
                mysqli_stmt_execute($stmt);

                $date = date("Y-m-d H:i:s");
                $stmt = mysqli_prepare($conn, "INSERT INTO user_log (created_date, user, status, campaign) VALUES (?, ?, 'LOGIN', ?)");
                mysqli_stmt_bind_param($stmt, "sss", $date, $username, $userWorkType1);
                mysqli_stmt_execute($stmt);

                $date = date("Y-m-d H:i:s");
                $stmt = mysqli_prepare($conn, "INSERT INTO user_log (created_date, user, status, total_sec, paused_code, campaign) VALUES (?, ?, 'PAUSED', '', 'LOGIN', ?)");
                mysqli_stmt_bind_param($stmt, "sss", $date, $username, $userWorkType1);
                mysqli_stmt_execute($stmt);

                if ($user_work_type == "WFO") {
                    header('Location: /haloocomConnect5/pages/connect5AgentPage/home.php');
                } else {
                    header('Location: /haloocomConnect5/pages/connect5AgentPage/home_responsive.php');
                }
                exit;
            } else {
                $_SESSION['AgentUserName'] = $username;
                $_SESSION['AgentPassword'] = $password;
                $GLOBALS['login_errorr'] = "USER ALREADY LOGIN, PLEASE CLICK ON THIS BUTTON "
                    . "<button type=\"button\" class=\"btn\"><a href=\"../../connect5AgentPage/logout.php\">Logout</a></button>";
                return;
            }
        } elseif (in_array($row_rs[0], ['D1', 'SuperAdmin', 'TelephonyAdmin', 'Supervisor', 'TL'])) {
            $_SESSION['username'] = $username;
            $_SESSION['pass']     = $password;
            header('Location: /haloocomConnect5/index.php');
            exit;
        }
    } else {
        $GLOBALS['login_errorr'] = "INVALID USERNAME OR PASSWORD";

        $stmt = mysqli_prepare($conn, "UPDATE users SET conference_number = '' WHERE user_id = ?");
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);

        $stmt = mysqli_prepare($conn, "UPDATE user_conference SET status = '0' WHERE conference_number = ?");
        mysqli_stmt_bind_param($stmt, "s", $user_conference_number);
        mysqli_stmt_execute($stmt);
    }
}

// ---------------------------------------------------------------------
// STEP 1: username + password submitted -> verify, then send OTP
// ---------------------------------------------------------------------
if (isset($_POST['Submit'])) {

    $username = trim($_POST['username']);
    $password = $_POST['pass'];

    if ($username !== "" && $password !== "") {

        $stmt = mysqli_prepare($conn, "SELECT id, user_id, user_level, user_password, user_email
                                        FROM users WHERE user_id = ?");
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0) {
            $row_rs = mysqli_fetch_assoc($result);

            // Plain comparison to match existing schema.
            // TODO (security): migrate to password_hash()/password_verify().
            if (hash_equals((string)$row_rs['user_password'], (string)$password)) {

                if (empty($row_rs['user_email'])) {
                    $login_errorr = "NO EMAIL ON FILE FOR THIS USER. PLEASE CONTACT YOUR ADMINISTRATOR.";
                } else {
                    // Always exactly 6 digits, never starts with 0, so there's
                    // no ambiguity between what's emailed and what's typed.
                    $otp = (string)random_int(100000, 999999);

                    $_SESSION['otp_code']          = $otp;
                    $_SESSION['otp_expiry']        = time() + 300; // 5 minutes
                    $_SESSION['otp_attempts']      = 0;
                    $_SESSION['pending_username']  = $username;
                    $_SESSION['pending_password']  = $password;

                    if (sendOtpEmail($row_rs['user_email'], $otp)) {
                        $otp_stage = true;
                        $masked_email = preg_replace('/^(.).*(@.*)$/', '$1***$2', $row_rs['user_email']);
                        $login_errorr = "AN OTP HAS BEEN SENT TO {$masked_email}";
                    } else {
                        $login_errorr = "COULD NOT SEND OTP EMAIL. PLEASE TRY AGAIN OR CONTACT YOUR ADMINISTRATOR.";
                    }
                }
            } else {
                $login_errorr = "INVALID USERNAME OR PASSWORD";
            }
        } else {
            $login_errorr = "INVALID USERNAME OR PASSWORD";
        }
    } else {
        $login_errorr = "USERNAME OR PASSWORD IS MISSING";
    }
}

// ---------------------------------------------------------------------
// STEP 2: OTP submitted -> verify, then run original login logic
// ---------------------------------------------------------------------
if (isset($_POST['VerifyOtp'])) {

    $submitted_otp = trim($_POST['otp']);

    if (!isset($_SESSION['otp_code']) || !isset($_SESSION['pending_username'])) {
        $login_errorr = "SESSION EXPIRED. PLEASE LOG IN AGAIN.";

    } elseif (time() > $_SESSION['otp_expiry']) {
        $login_errorr = "OTP EXPIRED. PLEASE LOG IN AGAIN.";
        unset($_SESSION['otp_code'], $_SESSION['otp_expiry'], $_SESSION['otp_attempts'],
              $_SESSION['pending_username'], $_SESSION['pending_password']);

    } elseif ($_SESSION['otp_attempts'] >= 5) {
        $login_errorr = "TOO MANY INCORRECT ATTEMPTS. PLEASE LOG IN AGAIN.";
        unset($_SESSION['otp_code'], $_SESSION['otp_expiry'], $_SESSION['otp_attempts'],
              $_SESSION['pending_username'], $_SESSION['pending_password']);

    } elseif (!preg_match('/^\d{6}$/', $submitted_otp)) {
        $login_errorr = "PLEASE ENTER ALL 6 DIGITS OF THE OTP.";
        $otp_stage = true;

    } elseif (!hash_equals($_SESSION['otp_code'], $submitted_otp)) {
        $_SESSION['otp_attempts']++;
        $login_errorr = "INCORRECT OTP. PLEASE TRY AGAIN.";
        $otp_stage = true;

    } else {
        $username = $_SESSION['pending_username'];
        $password = $_SESSION['pending_password'];
        unset($_SESSION['otp_code'], $_SESSION['otp_expiry'], $_SESSION['otp_attempts'],
              $_SESSION['pending_username'], $_SESSION['pending_password']);

        completeLogin($conn, $username, $password); // redirects + exits on success
        // If we reach here, completeLogin hit the "already logged in" branch
        // and set $login_errorr via $GLOBALS.
    }
}

$end_time = microtime(true);
$execution_time = ($end_time - $start_time);
echo "<!-- Page Execution Time: " . $execution_time . " seconds -->";
?>
<html lang="en">
<head>
	<title>Connect 6.0 Login Page </title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="stylesheet" type="text/css" href="css/custom.css">

<style>
/* Base & Reset */
* { box-sizing: border-box; }
body, html { min-height: 100%; margin: 0; padding: 0; background-color: #f0f2f5; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
.header { padding: 10px 20px; background: #1A2B6D; color: white; font-size: 13px; display: flex; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
.header img { max-height: 48px; width: auto; object-fit: contain; }
.limiter { width: 100%; min-height: calc(100vh - 68px); margin: 0 auto; }
.container-login100 { width: 100%; min-height: calc(100vh - 68px); display: flex; flex-direction: row; flex-wrap: wrap; justify-content: center; align-items: center; padding: 25px 15px; background-color: #f0f2f5; gap: 30px; box-sizing: border-box; }
#star { background-color: #ffffff; padding: 15px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); width: 250px; max-width: 100%; text-align: center; box-sizing: border-box; }
#star h4 { color: #1A2B6D; font-size: 16px; margin-top: 0; margin-bottom: 12px; font-weight: bold; }
.slider-container { width: 220px; height: 350px; overflow: hidden; margin: 0 auto; border-radius: 8px; }
.slider { display: flex; transition: transform 0.5s ease-in-out; }
.slide { flex: 0 0 100%; box-sizing: border-box; }
div.slider img { width: 220px; height: 250px; object-fit: cover; display: block; }
div.desc { width: 220px; height: 90px; padding: 8px; text-align: center; background-color: #1A2B6D; color: white; box-sizing: border-box; }
.wrap-login100, .container-login100 .wrap-login100 { width: 100% !important; max-width: 400px !important; min-width: 0 !important; background: #ffffff !important; border-radius: 12px !important; padding: 35px 30px 40px 30px !important; box-shadow: 0 4px 20px rgba(0,0,0,0.08) !important; box-sizing: border-box !important; margin: 20px auto !important; float: none !important; display: block !important; }
.logo-box, .wrap-login100 .logo-box { width: 100% !important; text-align: center !important; margin: 0 0 25px 0 !important; padding: 0 !important; float: none !important; }
.logo-box img, .wrap-login100 .logo-box img { max-width: 220px !important; width: auto !important; height: auto !important; max-height: 75px !important; margin: 0 auto !important; display: inline-block !important; float: none !important; }
.login-error, .wrap-login100 .login-error { width: 100% !important; text-align: center !important; margin: 0 0 15px 0 !important; padding: 0 !important; min-height: 20px !important; word-break: break-word !important; float: none !important; }
.wrap-login100 form, .wrap-login100 .login100-form1 { width: 100% !important; max-width: 100% !important; margin: 0 !important; padding: 0 !important; display: block !important; float: none !important; }
.wrap-login100 .form-group, .wrap-login100 form .form-group, .wrap-login100 .login100-form1 .form-group { width: 100% !important; max-width: 100% !important; margin: 0 0 18px 0 !important; padding: 0 !important; float: none !important; clear: both !important; text-align: left !important; box-sizing: border-box !important; }
.wrap-login100 label, .wrap-login100 form label, .wrap-login100 .login100-form1 label { display: block !important; width: 100% !important; text-align: left !important; margin: 0 0 6px 0 !important; padding: 0 !important; font-size: 13px !important; font-weight: 600 !important; color: #333333 !important; font-family: Helvetica, Arial, sans-serif !important; float: none !important; }
.wrap-login100 .form-control, .wrap-login100 form input[type="text"], .wrap-login100 form input[type="password"], .wrap-login100 .login100-form1 .form-control { display: block !important; width: 100% !important; max-width: 100% !important; min-width: 100% !important; height: 44px !important; margin: 0 !important; padding: 8px 14px !important; font-size: 14px !important; border-radius: 6px !important; border: 1px solid #ced4da !important; box-sizing: border-box !important; float: none !important; background-color: #ffffff !important; transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out !important; }
.wrap-login100 .form-control:focus, .wrap-login100 form input:focus { border-color: #1A2B6D !important; outline: 0 !important; box-shadow: 0 0 0 0.2rem rgba(26,43,109,0.25) !important; background-color: #ffffff !important; }
.wrap-login100 select.form-control, .wrap-login100 .select2-container { width: 100% !important; max-width: 100% !important; margin: 0 !important; }
.container-login100-form-btn1, .wrap-login100 .container-login100-form-btn1 { width: 100% !important; display: flex !important; justify-content: center !important; align-items: center !important; text-align: center !important; margin: 24px 0 0 0 !important; padding: 0 !important; float: none !important; }
.login100-form-btn, .wrap-login100 .login100-form-btn { display: inline-block !important; width: 100% !important; max-width: 200px !important; height: 44px !important; line-height: 44px !important; border-radius: 22px !important; background-color: #1A2B6D !important; color: #ffffff !important; font-size: 15px !important; font-weight: bold !important; border: none !important; cursor: pointer !important; margin: 0 auto !important; padding: 0 20px !important; text-align: center !important; float: none !important; transition: all 0.3s ease !important; box-shadow: 0 4px 10px rgba(26,43,109,0.25) !important; }
.login100-form-btn:hover, .wrap-login100 .login100-form-btn:hover { background-color: #132053 !important; box-shadow: 0 6px 15px rgba(26,43,109,0.35) !important; }
.otp-input { letter-spacing: 8px; font-size: 22px !important; text-align: center !important; font-weight: bold; }
@media (max-width: 768px) {
  .header { padding: 8px 15px !important; }
  .header img { max-height: 40px !important; }
  .container-login100 { flex-direction: column !important; justify-content: flex-start !important; align-items: center !important; padding: 20px 15px 35px 15px !important; gap: 20px !important; min-height: auto !important; }
  .container-login100 .wrap-login100 { max-width: 100% !important; width: 100% !important; padding: 25px 20px 30px 20px !important; margin: 10px 0 !important; box-shadow: 0 2px 10px rgba(0,0,0,0.06) !important; }
  #star { margin: 0 auto !important; width: 100% !important; max-width: 260px !important; }
  .logo-box img, .wrap-login100 .logo-box img { max-width: 200px !important; }
  .login100-form-btn, .wrap-login100 .login100-form-btn { max-width: 100% !important; }
}
@media (max-width: 480px) {
  .header { padding: 6px 12px !important; }
  .header img { max-height: 35px !important; }
  .container-login100 { padding: 15px 10px 25px 10px !important; gap: 15px !important; }
  .container-login100 .wrap-login100 { padding: 20px 15px 25px 15px !important; border-radius: 10px !important; }
  .logo-box { margin-bottom: 15px !important; }
  .logo-box img, .wrap-login100 .logo-box img { max-width: 180px !important; }
  .wrap-login100 .form-control, .wrap-login100 form input[type="text"], .wrap-login100 form input[type="password"], .wrap-login100 .login100-form1 .form-control { font-size: 16px !important; height: 42px !important; }
  .wrap-login100 label, .wrap-login100 form label, .wrap-login100 .login100-form1 label { font-size: 12px !important; }
  .login100-form-btn, .wrap-login100 .login100-form-btn { height: 42px !important; font-size: 14px !important; }
}
</style>
</head>
<body>
<div class="header">
  <div><img src="images/wp_logo1.png" alt="Logo"></div>
</div>

	<div class="limiter">
		<div class="container-login100">
		<?php if ($star_month == 1): ?>
		<div id="star">
		<h4 style="color: #1A2B6D; text-align: center; margin-bottom: 15px;"><b><i class="fa fa-star" aria-hidden="true"></i> Star Of The Month <i class="fa fa-star" aria-hidden="true"></i></b></h4>
<div class="slider-container">
  <div class="slider">
  <?php
    $stmt_select = mysqli_prepare($conn, "SELECT * FROM start_month");
    mysqli_stmt_execute($stmt_select);
    $rslt_rs = mysqli_stmt_get_result($stmt_select);
    while ($row = mysqli_fetch_assoc($rslt_rs)) {
  ?>
    <div class="slide">
<img src="star_images/<?php echo htmlspecialchars($row["image_path"]); ?>" alt="Image 1" width="600" height="400">
<div class="desc">
  <div style="margin-top:5px;"><b><?php echo htmlspecialchars($row["name"]); ?></b></div>
  <div style="margin-top:10px;"><?php echo htmlspecialchars($row["designation"]); ?></div>
</div>
	</div>
  <?php } ?>
  </div>
</div>
  </div>
  <?php endif; ?>

			<div class="wrap-login100" style="width: 100%; max-width: 380px; margin: 20px auto; padding: 35px 30px; box-sizing: border-box; background: #ffffff; border-radius: 12px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);">
				<div class="logo-box" style="text-align: center; margin: 0 0 25px 0; padding: 0; width: 100%;">
					<img src="images/hexa.png" alt="Logo" style="max-width: 200px; height: auto; display: block; margin: 0 auto;">
				</div>

                <div class="form-group login-error" style="text-align: center; margin: 0 0 15px 0; padding: 0; width: 100%;">
				  <font color="red" size="2"><?php echo $login_errorr; ?></font>
				</div>

				<?php if (!$otp_stage): ?>
				<form class="login100-form1 validate-form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" style="width: 100%; margin: 0; padding: 0; display: block;">
					<div class="form-group" style="width: 100%; margin: 0 0 18px 0; padding: 0; clear: both;">
					  <label for="username">Enter Login ID:</label>
					  <input type="text" class="form-control" name="username" id="username" placeholder="Enter username" required>
					</div>
					<div class="form-group" style="width: 100%; margin: 0 0 18px 0; padding: 0; clear: both;">
					  <label for="pass">Enter Password:</label>
					  <input class="form-control" type="password" name="pass" id="pass" placeholder="Enter password" required>
					</div>
					<div class="container-login100-form-btn1">
						<input type="submit" class="login100-form-btn" name="Submit" value="Login">
					</div>
				</form>
				<?php else: ?>
				<form class="login100-form1 validate-form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" style="width: 100%; margin: 0; padding: 0; display: block;">
					<div class="form-group" style="width: 100%; margin: 0 0 18px 0; padding: 0; clear: both;">
					  <label for="otp">Enter the 6-digit OTP sent to your email:</label>
					  <input type="text" class="form-control otp-input" name="otp" id="otp"
					         maxlength="6" inputmode="numeric" autocomplete="one-time-code"
					         placeholder="------" required autofocus
					         oninput="this.value = this.value.replace(/\D/g, '').slice(0, 6);">
					</div>
					<div class="container-login100-form-btn1">
						<input type="submit" class="login100-form-btn" name="VerifyOtp" value="Verify OTP">
					</div>
				</form>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="vendor/animsition/js/animsition.min.js"></script>
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="vendor/select2/select2.min.js"></script>
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
	<script src="vendor/countdowntime/countdowntime.js"></script>
	<script src="js/main.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(document).ready(function() {
    var slideCount = $('.slide').length;
    var slideWidth = $('.slide').width();
    var sliderWidth = slideCount * slideWidth;
    $('.slider').css('width', sliderWidth);

    function autoplay() {
      $('.slider').animate({ marginLeft: -slideWidth }, 1000, function() {
        $('.slider .slide:first').appendTo('.slider');
        $('.slider').css('marginLeft', 0);
      });
    }
    var autoplayInterval = setInterval(autoplay, 4000);
    $('.slider-container').hover(function() {
      clearInterval(autoplayInterval);
    }, function() {
      autoplayInterval = setInterval(autoplay, 4000);
    });
  });
</script>
</body>
</html>