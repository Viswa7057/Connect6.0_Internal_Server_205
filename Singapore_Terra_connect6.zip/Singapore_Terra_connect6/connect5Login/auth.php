<?php
    require_once("dbconnect_mysqli.php");
    date_default_timezone_set('Asia/Kolkata');
    $start = date('Y-m-d H:i:s');
    $sel = "select access_token,end_time,id from zoho_details";
    $res = mysqli_query($link,$sel);
    $row = mysqli_fetch_array($res);
   $curtimestamp1 = strtotime($start);
   $curtimestamp2 = strtotime($row[1]);
   if ($curtimestamp1 < $curtimestamp2)
   {
         $access_token = $row[0];
   }
   else
   {
         $end   = date('Y-m-d H:i:s',strtotime('+1 hour',strtotime($start)));
         $handle = curl_init();
       	 $url = "https://accounts.zoho.in/oauth/v2/token";
       	 $postData = array(
  	     'refresh_token' => '1000.53915e32cb46730c575403c3795310ce.12ff95104a9c3f11495027e73553ff48',
         'client_id'  => '1000.1SYOLHU5IUNYB40I2OQF7SS0CHZC3W',
         'client_secret'    => '5dad4ec2fadf91345f49ca3130a2979a77a6f07ae9',
         'grant_type'     => 'refresh_token'
         );
         curl_setopt_array($handle,
         array(
         CURLOPT_URL => $url,
         CURLOPT_POST       => true,
         CURLOPT_POSTFIELDS => $postData,
         CURLOPT_RETURNTRANSFER     => true,
         )
         );
         $data = curl_exec($handle);
	 curl_close($handle);
	 print_r($data);
	 $token = json_decode($data,true);
	 print_r($token);
	 $access_token = $token['access_token'];
	 $sel ="update zoho_details set start_time= '$start',end_time= '$end' ,access_token='$access_token' where id = '$row[2]'";
	 $res = mysqli_query($link,$sel);
   }

 echo "=ACCESS TOKEN".$access_token;

			
?>