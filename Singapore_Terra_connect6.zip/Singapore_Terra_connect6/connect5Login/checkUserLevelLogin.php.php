<?php 
							$userName = 'sandeep'; //$_REQUEST['username'];
						date_default_timezone_set('asia/kolkata');
							$mongo = new MongoDB\Driver\Manager("mongodb://localhost:27017");    
							$bulk = new MongoDB\Driver\BulkWrite;
							$filter = [ 'user_name' => "$userName","status" => "Active" ];							
							$options = [ 'sort' => ['created_date' => -1],'limit'=> 1 ];  //
							$qry = new MongoDB\Driver\Query($filter,$options);
							$date = date("Y-m-d H:i:s");
							$rowsExtension = $mongo->executeQuery("admin.users", $qry); 
							$ex =  $rowsExtension->toArray();
							$extensionIDArray = json_decode(json_encode($ex), true);
							echo "<pre>";
							print_r($extensionIDArray[0]);
							exit;
							if(count($extensionIDArray) > 0 ){
								echo "";
							}



?>