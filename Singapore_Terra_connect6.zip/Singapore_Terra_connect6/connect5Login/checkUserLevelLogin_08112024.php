<?php 

require_once("db_connect.php");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

									$userName = $_REQUEST['username'];
						$stmt_rs="SELECT user_level,Campaign,user_group from users where user_id='$userName' AND status='Active';";
						//echo $stmt_rs; 
	                           $rslt_rs= mysqli_query($conn,$stmt_rs);
	                           $row_rs= mysqli_fetch_row($rslt_rs);
		
							$user_level = $row_rs[0];
							$campign = $row_rs[1];
							$user_group = $row_rs[2];
							
							if(count($row_rs) > 0 ){
								if($user_level == 'SuperAdmin' || $user_level == 'Admin')
								{
								echo "admin"; 
								echo "=====";exit;
								}
								else
								{
								echo "display";
								echo "=====";
								?>
								<option value="">--Select Campaign--</option>
					 <?php
                       $stmt_select1="SELECT campaign_id,campaign_name from campaign where active_camp='Y' AND user_group='$user_group'";
					  // echo $stmt_select1;
	                   $rslt_rs1= mysqli_query($conn,$stmt_select1);
	                 	while($row1 = mysqli_fetch_assoc($rslt_rs1)) {
							  ?>
						<option value = "<?php echo $row1["campaign_id"]; ?>" ><?php echo $row1["campaign_name"]; ?></option>
			        <?php } ?>
					<?php
								echo "=====";exit;
								}
							}else{
								echo "No display";exit;
							}



?>