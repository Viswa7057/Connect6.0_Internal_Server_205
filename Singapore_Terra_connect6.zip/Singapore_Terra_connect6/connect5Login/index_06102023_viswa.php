<?php 

require_once("db_connect.php");

error_reporting(E_ERROR | E_WARNING | E_PARSE);
   session_start();
   $login_errorr_cnt=1;
   $login_errorr="";
   
    if (isset($_POST['Submit']))
   {  
       
	    $username = $_POST['username'];
		$password = $_POST['pass'];
		$userlocation = $_POST['userlocation'];
		$userWorkType1  = $_POST['userWorkType'];
		
		 
     if( $username != "" && $password != "" ) 
	  {
		
	$stmt_rs="SELECT user_level,extension_id,conference_number from users where user_name='$username' AND user_password='$password';";
	                           $rslt_rs= mysqli_query($conn,$stmt_rs);
	                           $row_rs= mysqli_fetch_row($rslt_rs);
							   
	
		 
          if(count($row_rs) > 0)
		  {
			
		   $_SESSION['user_level'] = $row_rs[0];
		   $userExtension = $row_rs[1];
		   $Conf_Number = $row_rs[2];
		   
		  // echo $userLocation;exit; 
		
		
					if($row_rs[0] == 'D4'){
							$_SESSION['AgentUserName'] = $username;
								$_SESSION['AgentPassword'] = $password;
								$_SESSION['extension'] = $userExtension;
								$_SESSION['campaign'] =$userWorkType1;
								
						
							$stmt_rs1="SELECT id from user_live where user ='$username';";
	                           $rslt_rs1= mysqli_query($conn,$stmt_rs1);
	                           $row_rs1= mysqli_fetch_row($rslt_rs1);
	
							 if(count($row_rs1) == 0){
								 
									$date = date("Y-m-d H:i:s");
									
	$stmt_insert_live="insert into user_live(created_date,user,status,extension,callstatus,campaign,confnum,auto_flag,waittime,timer,pause_flag) values('$date','$username','PAUSED','$userExtension','IDLE','$userWorkType1','$Conf_Number','0','$date','0','0');";
							//	echo $stmt_insert_live; exit;
	                           $rslt_insert_live= mysqli_query($conn,$stmt_insert_live);
								 
								 
								 
								
								$date = date("Y-m-d H:i:s");
							
				$stmt_insert_log="insert into user_log(created_date,user,status) values('$date','$username','LOGIN');";
	                           $rslt_insert_log= mysqli_query($conn,$stmt_insert_log);
								 
								
								$date = date("Y-m-d H:i:s");
							
$stmt_insert_log1="insert into user_log(created_date,user,status,total_sec,paused_code) values('$date','$username','PAUSED','','LOGIN');";
	                           $rslt_insert_log1= mysqli_query($conn,$stmt_insert_log1);
								 
									
								header('Location: /haloocomConnect5/pages/connect5AgentPage/home.php');   //haloocomConnect5/pages/haloocomConnect5_O/home.php
						 }else{
							  $login_errorr_cnt=1;
							  $login_errorr="USER ALREADY LOGIN, PLEASE CLICK ON THIS BUTTON <button type = \"button\" class = \"btn\"><a href=\"../../Agent_mongodb/logout.php\" >Logout</a></button>";
						} 
					
					}else if($row_rs[0] == 'D1' || $row_rs[0] == 'SuperAdmin' || $row_rs[0] == 'SuperUserAccess'){
						 $_SESSION['username'] = $username;
						$_SESSION['pass'] = $password;
						
						header('Location: /haloocomConnect5/index.php');
					}
			
		 }
		 else
		 {
          $login_errorr_cnt=1;
          $login_errorr="INVALID USERNAME OR PASSWORD  ";
         }

     }
     else
     {
		 $login_errorr_cnt=1;
         $login_errorr = "USERNAME OR PASSWORD IS MISSING ";
     }
  }





?>
<html lang="en">
<head>


<style>



</style>
	<title>Connect 6.0 Login Page </title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	
	
	
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/custom.css">

<style>
.header {
  padding: 8px;
 // text-align: center;
  background: #1A2B6D;
  color: white;
  font-size: 13px;
}
#star {
	background-color: white;
	
}
.scrolling-div{
  width: 200px;
  height: 600px;
  background-color: white;
  overflow: hidden;
}

.scrolling-content {
 animation: scrollUp 30s linear infinite;
  scroll-behavior: smooth;
}

@keyframes scrollUp {
  0% {
    transform: translateY(0%);
  }
  100% {
    transform: translateY(-800%);
 

  }
}


div.scrolling-content {
  border: 1px solid #777;
}

div.scrolling-content img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 5px;
  text-align: center;
  background-color: #1A2B6D;
  color: white;
}
</style>
</head>
<body>
<div class="header">
  <div><img src = "images/wp_logo.png" width = "50px" height = "45px">&nbsp;&nbsp;<b>HALOOCOM</b></div>

</div>

	
   
	<div class="limiter">
		<div class="container-login100">
		
		<div id="star" style="justify-content: left; padding:10px;margin-top:10px; border-radius:10px; height:700px;">
		<p><h4 style="align:center; color: #1A2B6D;"><b><i class="fa fa-star" aria-hidden="true"></i> Star Of The Month <i class="fa fa-star" aria-hidden="true"></i></b></h4></p><br>
		<div class="scrolling-div" style="height:600px;">
		<?php 
							$stmt_select="SELECT * from start_month";
	                  $rslt_rs= mysqli_query($conn,$stmt_select);
	                 
					 $x = 1;		
			   while($row = mysqli_fetch_assoc($rslt_rs)) {
				   ?>
				   <div class="scrolling-content">
	<?php echo '<img src="data:image/jpeg;base64,'.base64_encode($row['image_data']).'" width="600" height="400"/>';; ?>
  </a>
  <div class="desc"><b><?php echo $row["name"]; ?></b></div>
  <div class="desc"><?php echo $row["designation"]; ?></div>

    </div><br><br>
	 <?php $x++; } ?>
</div>
  </div>
			<div class="wrap-login100" style="height: 525px; margin-left:300px; margin-top:30px;">
				<div class="login100-form-title" style="background-image: url(images/wp_logo.png); z-index: unset !important;width: 131px;height: 55px;">

					<span class="login100-form-title-1" style = "display:none1">
						Connect 6.0
					</span>
				</div>
				
                <div class="form-group" style="margin-top: 57px !important;margin-bottom: -9px !important;margin-left: 60px !important;">
				  <font color="red" size = "2">
				   <?php 
				   if($login_errorr_cnt =='1')
				   echo $login_errorr;
			       else
				   echo $login_errorr;
				   ?>
				  </font>
				</div>
				<br>
				<form class="login100-form1 validate-form" action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
					<div class="form-group" style="margin-bottom:-15px !important;">
					  <label for="username">Enter Login ID:</label>
					  <input type="text" class="form-control" name="username" id = "username" placeholder="Enter username" onchange = "checkUserLevelLogin();" >
					</div> <br>
					<div class="form-group" style="margin-bottom:-15px !important;">
					  <label for="pass">Enter Password:</label>
					  <input class="form-control" type="password" name="pass" placeholder="Enter password">
					</div>
					<div class="form-group"  id = "userWorkTypeDivId" style = "display:none;margin-top: 35px">
					 <label for ="campaign"> Campaign	</label>	
			        <input class="form-control" type="text" name ="userWorkType" id = "userWorkType" readonly >
					</div>
				

					<br><br>
					
					<div class="container-login100-form-btn1">
						
						<input  type="submit" class="login100-form-btn" name="Submit" value="Login"  style = "margin-left: 89px;">
					</div>
				</form>
					  
			</div>
		</div>
	</div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
	<script>
  const scrollingContent = document.querySelector('.scrolling-content');
const image = scrollingContent.querySelector('img');

/*
function scrollToTop() {
  scrollingContent.style.transform = 'translateY(0)';
  setTimeout(() => {
    scrollingContent.style.transform = 'translateY(-100%)';
    setTimeout(scrollToTop, 20000); 
  }, 20000);
}

scrollToTop();
*/

</script>
	<script>
		function checkUserLevelLogin(){
			var username = document.getElementById("username").value;
			
			/*	const xhttp = new XMLHttpRequest();
				  xhttp.onload = function() {
					var result =  this.responseText;
					var res = result.split("=====");
					//alert(res);
					 
						if((res[0] == "display")){
						document.getElementById("userWorkTypeDivId").style.display ="block";
						document.getElementById('userWorkType').value=res[1];
						document.getElementById("userWorkType").required  =true;
				
						}
						else if(res[0] == 'No display'){
							document.getElementById("userWorkTypeDivId").style.display ="none";
							document.getElementById("userWorkType").required  =false;
							
						}
						 else if(res[0] == 'admin'){
							document.getElementById("userWorkTypeDivId").style.display ="none";
							document.getElementById("userWorkType").required  =false;
							document.getElementById("supportType").style.display ="none";
							document.getElementById("supportWorkType").required  =false;
							
							
						}
					}
				  xhttp.open("GET", "checkUserLevelLogin.php?username="+username, true);
				  xhttp.send(); */
				  
				  $.ajax({
			type: 'POST',
			url: "checkUserLevelLogin.php",
			data: {
				'username': username
			},
			success: function(result) {
				var res = result.split("=====");
				//alert(result);
				
		      if((res[0] == "display")){
						document.getElementById("userWorkTypeDivId").style.display ="block";
						document.getElementById('userWorkType').value=res[1];
						document.getElementById("userWorkType").required  =true;
				
						}
						else if(res[0] == 'No display'){
							document.getElementById("userWorkTypeDivId").style.display ="none";
							document.getElementById("userWorkType").required  =false;
							
						}
						 else if(res[0] == 'admin'){
							document.getElementById("userWorkTypeDivId").style.display ="none";
							document.getElementById("userWorkType").required  =false;
							document.getElementById("supportType").style.display ="none";
							document.getElementById("supportWorkType").required  =false;
							
							
						}
			}
		});
		}
	</script>
	
</body>
</html>