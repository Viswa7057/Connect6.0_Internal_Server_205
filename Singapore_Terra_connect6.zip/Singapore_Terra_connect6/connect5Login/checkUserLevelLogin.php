<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once("db_connect.php");

$userName = $_POST['username'] ?? '';

if ($userName == '') {
    echo "No display";
    exit;
}

$stmt_rs = "SELECT user_level, Campaign, user_group 
            FROM users 
            WHERE user_id='$userName' AND status='Active'";

$rslt_rs = mysqli_query($conn, $stmt_rs);
if (!$rslt_rs) {
    die(mysqli_error($conn));
}

$row_rs = mysqli_fetch_row($rslt_rs);

if ($row_rs) {

    $user_level = $row_rs[0];
    $user_group = $row_rs[2];

    if (in_array($user_level, ['SuperAdmin','TelephonyAdmin','Supervisor','TL'])) {
        echo "admin=====";
        exit;
    }

    echo "display=====";
    ?>

    <option value="">--Select Campaign--</option>
    <?php
    $stmt_select1 = "SELECT campaign_id, campaign_name 
                     FROM campaign 
                     WHERE active_camp='Y' AND user_group='$user_group'";
	//echo $stmt_select1;

    $rslt_rs1 = mysqli_query($conn, $stmt_select1);

    while ($row1 = mysqli_fetch_assoc($rslt_rs1)) { ?>
        <option value="<?= $row1['campaign_id']; ?>">
            <?= $row1['campaign_name']; ?>
        </option>
    <?php }

    echo "=====";

    ?>

    <option value="">--Assigned Ingroups--</option>
    <?php
    $sql = "SELECT ingroup FROM users WHERE user_id='$userName'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if (!empty($row['ingroup'])) {
        $user_ingroups = array_map('trim', explode(',', $row['ingroup']));
        foreach ($user_ingroups as $ingroup) { ?>
            <option value="<?= $ingroup; ?>"><?= $ingroup; ?></option>
        <?php }
    }

    exit;

} else {
    echo "No display";
    exit;
}
