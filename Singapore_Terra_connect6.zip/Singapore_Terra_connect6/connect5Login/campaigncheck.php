<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once("db_connect.php");

$campaign = $_POST['campaign'] ?? '';
$userName = $_POST['username'] ?? '';

if ($campaign == '') {
    echo "No display";
    exit;
}

$stmt_rs = "SELECT dial_method FROM campaign WHERE campaign_id='$campaign'";

$rslt_rs = mysqli_query($conn, $stmt_rs);
if (!$rslt_rs) {
    die(mysqli_error($conn));
}

$row_rs = mysqli_fetch_row($rslt_rs);

if ($row_rs) {

    $dial_method = $row_rs[0];
    

    if (in_array($dial_method, ['Inbound','Blended'])) {
        echo "display=====";
       
    }else{
		echo "No display=====";
		exit;
	}
   
    ?>

    <?php
    $sql = "SELECT ingroup FROM users WHERE user_id='$userName'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if (!empty($row['ingroup'])) {
        $user_ingroups = array_map('trim', explode(',', $row['ingroup']));
        foreach ($user_ingroups as $ingroup) { ?>
            <option value="<?= $ingroup; ?>"><?= $ingroup; ?></option>
        <?php }
    }

    exit;

} else {
    echo "No display";
    exit;
}
