<?php
$conn = mysqli_connect("localhost","root","Hal0o(0m@72427242","halootel");
?>