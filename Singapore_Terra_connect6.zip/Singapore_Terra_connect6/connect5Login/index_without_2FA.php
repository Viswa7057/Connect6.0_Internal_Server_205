<?php
$start_time = microtime(true);
require_once("db_connect.php");

$stmt_select="SELECT * from features_settings";
	      $rslt_rs= mysqli_query($conn,$stmt_select);

                           if(mysqli_num_rows($rslt_rs)>=1){
			   while($row = mysqli_fetch_assoc($rslt_rs)) {
				  $star_month = $row["star_month"];

			   }
			   }

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);  


error_reporting(E_ERROR | E_WARNING | E_PARSE);

   session_start();
   $login_errorr_cnt=1;
   $login_errorr="";

    if (isset($_POST['Submit']))
   {

	    $username = $_POST['username'];

		$password = $_POST['pass'];
		//$userlocation = $_POST['userlocation'];
		


     if( $username != "" && $password != "" )
	  {
///added by nagendra
$resd = mysqli_query($conn,"select agent from user_conference where agent=(select extension_id from users where user_id='$username')");
if(mysqli_num_rows($resd)>=1){
$rowd=mysqli_fetch_array($resd);
$agd = $rowd['agent'];
mysqli_query($conn,"update user_conference set agent='',status='0' where agent='$agd'");}
mysqli_query($conn,"update user_conference set status='0' where agent=''");

$stmt_con="SELECT conference_number from user_conference where status='0' ORDER BY id ASC LIMIT 1";
	                           $rslt_con= mysqli_query($conn,$stmt_con);
	                           $row_con= mysqli_fetch_row($rslt_con);
				   $user_conference_number = $row_con[0];

				   $query_update = "update users set conference_number='$user_conference_number' where user_id='$username' and user_level='D4'";

				   mysqli_query($conn,$query_update);


$query_conf = "update user_conference set status='1' where conference_number='$user_conference_number'";
mysqli_query($conn,$query_conf);
	$stmt_rs="SELECT user_level,extension_id,conference_number,Campaign,work_type from users where user_id='$username' AND user_password='$password';";


	                           $rslt_rs= mysqli_query($conn,$stmt_rs);
	                           $row_rs= mysqli_fetch_array($rslt_rs);



				   if(mysqli_num_rows($rslt_rs) > 0)
		  {

		   $_SESSION['user_level'] = $row_rs[0];
		   $userExtension = $row_rs[1];
		   $Conf_Number = $row_rs[2];
		   $userWorkType1  = $row_rs[3];
		   $user_work_type  = $row_rs[4];
		  mysqli_query($conn,"update user_conference set agent='$userExtension' where conference_number='$user_conference_number'");
		  // echo $userLocation;exit;

		//echo $row_rs[0]; exit;
					if($row_rs[0] == 'D4'){
							$_SESSION['AgentUserName'] = $username;
								$_SESSION['AgentPassword'] = $password;
								$_SESSION['extension'] = $userExtension;
								$_SESSION['campaign'] =$userWorkType1;
								$_SESSION['conf_num']=$Conf_Number;

                $camp_stmt = "select user_group from campaign where campaign_id='$userWorkType1';";
                $camp_rslt = mysqli_query($conn,$camp_stmt);
                $camp_rows = mysqli_fetch_array($camp_rslt);
                $_SESSION['User_Group']=$camp_rows['user_group'];

							$stmt_rs1="SELECT id from user_live where user ='$username';";
	                           $rslt_rs1= mysqli_query($conn,$stmt_rs1);
	                           $row_rs1= mysqli_fetch_row($rslt_rs1);

							 if($row_rs1 == ""){

									$date = date("Y-m-d H:i:s");

	$stmt_insert_live="insert into user_live(created_date,user,status,extension,callstatus,campaign,confnum,auto_flag,waittime,timer,pause_flag,ringroup) values('$date','$username','PAUSED','$userExtension','IDLE','$userWorkType1','$Conf_Number','0','$date','0','0','');";
								//echo $stmt_insert_live; exit;
	                           $rslt_insert_live= mysqli_query($conn,$stmt_insert_live);




								$date = date("Y-m-d H:i:s");

	$stmt_insert_log="insert into user_log(created_date,user,status,campaign) values('$date','$username','LOGIN','$userWorkType1');";

	                           $rslt_insert_log= mysqli_query($conn,$stmt_insert_log);


								$date = date("Y-m-d H:i:s");

$stmt_insert_log1="insert into user_log(created_date,user,status,total_sec,paused_code,campaign) values('$date','$username','PAUSED','','LOGIN','$userWorkType1');";
	                           $rslt_insert_log1= mysqli_query($conn,$stmt_insert_log1);

							 if($user_work_type == "WFO"){
								header('Location: /haloocomConnect5/pages/connect5AgentPage/home.php');   //haloocomConnect5/pages/haloocomConnect5_O/home.php
							 }else{
								 header('Location: /haloocomConnect5/pages/connect5AgentPage/home_responsive.php');   //haloocomConnect5/pages/haloocomConnect5_O/home.php
							 }
						 }else{
							 $_SESSION['AgentUserName'] = $username;
								$_SESSION['AgentPassword'] = $password;
							  $login_errorr_cnt=1;
							 $login_errorr="USER ALREADY LOGIN, PLEASE CLICK ON THIS BUTTON <button type = \"button\" class = \"btn\"><a href=\"../../connect5AgentPage/logout.php\">Logout</a></button>";
						}

					}else if($row_rs[0] == 'D1' || $row_rs[0] == 'SuperAdmin' || $row_rs[0] == 'TelephonyAdmin' || $row_rs[0] == 'Supervisor' || $row_rs[0] == 'TL'){
						 $_SESSION['username'] = $username;
						$_SESSION['pass'] = $password;

						header('Location: /haloocomConnect5/index.php');
					}

		 }
		 else
		 {
          $login_errorr_cnt=1;
          $login_errorr="INVALID USERNAME OR PASSWORD  ";

		  $query_update = "update users set conference_number='' where user_id='$username'";
mysqli_query($conn,$query_update);

$query_conf = "update user_conference set status='0' where conference_number='$user_conference_number'";
mysqli_query($conn,$query_conf);

         }

     }
     else
     {
		 $login_errorr_cnt=1;
         $login_errorr = "USERNAME OR PASSWORD IS MISSING ";
     }
  }




$end_time = microtime(true);
$execution_time = ($end_time - $start_time);

echo "<!-- Page Execution Time: " . $execution_time . " seconds -->";


?>
<html lang="en">
<head>



	<title>Connect 6.0 Login Page </title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">



<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/custom.css">

<style>
/* Base & Reset */
* {
  box-sizing: border-box;
}

body, html {
  min-height: 100%;
  margin: 0;
  padding: 0;
  background-color: #f0f2f5;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}

.header {
  padding: 10px 20px;
  background: #1A2B6D;
  color: white;
  font-size: 13px;
  display: flex;
  align-items: center;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.header img {
  max-height: 48px;
  width: auto;
  object-fit: contain;
}

.limiter {
  width: 100%;
  min-height: calc(100vh - 68px);
  margin: 0 auto;
}

.container-login100 {
  width: 100%;
  min-height: calc(100vh - 68px);
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  padding: 25px 15px;
  background-color: #f0f2f5;
  gap: 30px;
  box-sizing: border-box;
}

/* Star of the Month */
#star {
  background-color: #ffffff;
  padding: 15px;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
  width: 250px;
  max-width: 100%;
  text-align: center;
  box-sizing: border-box;
}

#star h4 {
  color: #1A2B6D;
  font-size: 16px;
  margin-top: 0;
  margin-bottom: 12px;
  font-weight: bold;
}

.slider-container {
  width: 220px;
  height: 350px;
  overflow: hidden;
  margin: 0 auto;
  border-radius: 8px;
}

.slider {
  display: flex;
  transition: transform 0.5s ease-in-out;
}

.slide {
  flex: 0 0 100%;
  box-sizing: border-box;
}

div.slider img {
  width: 220px;
  height: 250px;
  object-fit: cover;
  display: block;
}

div.desc {
  width: 220px;
  height: 90px;
  padding: 8px;
  text-align: center;
  background-color: #1A2B6D;
  color: white;
  box-sizing: border-box;
}

/* Login Card */
.wrap-login100,
.container-login100 .wrap-login100 {
  width: 100% !important;
  max-width: 400px !important;
  min-width: 0 !important;
  background: #ffffff !important;
  border-radius: 12px !important;
  padding: 35px 30px 40px 30px !important;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08) !important;
  box-sizing: border-box !important;
  margin: 20px auto !important;
  float: none !important;
  display: block !important;
}

.logo-box,
.wrap-login100 .logo-box {
  width: 100% !important;
  text-align: center !important;
  margin: 0 0 25px 0 !important;
  padding: 0 !important;
  float: none !important;
}

.logo-box img,
.wrap-login100 .logo-box img {
  max-width: 220px !important;
  width: auto !important;
  height: auto !important;
  max-height: 75px !important;
  margin: 0 auto !important;
  display: inline-block !important;
  float: none !important;
}

.login-error,
.wrap-login100 .login-error {
  width: 100% !important;
  text-align: center !important;
  margin: 0 0 15px 0 !important;
  padding: 0 !important;
  min-height: 20px !important;
  word-break: break-word !important;
  float: none !important;
}

.wrap-login100 form,
.wrap-login100 .login100-form1 {
  width: 100% !important;
  max-width: 100% !important;
  margin: 0 !important;
  padding: 0 !important;
  display: block !important;
  float: none !important;
}

.wrap-login100 .form-group,
.wrap-login100 form .form-group,
.wrap-login100 .login100-form1 .form-group {
  width: 100% !important;
  max-width: 100% !important;
  margin: 0 0 18px 0 !important;
  padding: 0 !important;
  float: none !important;
  clear: both !important;
  text-align: left !important;
  box-sizing: border-box !important;
}

.wrap-login100 label,
.wrap-login100 form label,
.wrap-login100 .login100-form1 label {
  display: block !important;
  width: 100% !important;
  text-align: left !important;
  margin: 0 0 6px 0 !important;
  padding: 0 !important;
  font-size: 13px !important;
  font-weight: 600 !important;
  color: #333333 !important;
  font-family: Helvetica, Arial, sans-serif !important;
  float: none !important;
}

.wrap-login100 .form-control,
.wrap-login100 form input[type="text"],
.wrap-login100 form input[type="password"],
.wrap-login100 .login100-form1 .form-control {
  display: block !important;
  width: 100% !important;
  max-width: 100% !important;
  min-width: 100% !important;
  height: 44px !important;
  margin: 0 !important;
  padding: 8px 14px !important;
  font-size: 14px !important;
  border-radius: 6px !important;
  border: 1px solid #ced4da !important;
  box-sizing: border-box !important;
  float: none !important;
  background-color: #ffffff !important;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out !important;
}

.wrap-login100 .form-control:focus,
.wrap-login100 form input:focus {
  border-color: #1A2B6D !important;
  outline: 0 !important;
  box-shadow: 0 0 0 0.2rem rgba(26, 43, 109, 0.25) !important;
  background-color: #ffffff !important;
}

.wrap-login100 select.form-control,
.wrap-login100 .select2-container {
  width: 100% !important;
  max-width: 100% !important;
  margin: 0 !important;
}

.container-login100-form-btn1,
.wrap-login100 .container-login100-form-btn1 {
  width: 100% !important;
  display: flex !important;
  justify-content: center !important;
  align-items: center !important;
  text-align: center !important;
  margin: 24px 0 0 0 !important;
  padding: 0 !important;
  float: none !important;
}

.login100-form-btn,
.wrap-login100 .login100-form-btn {
  display: inline-block !important;
  width: 100% !important;
  max-width: 200px !important;
  height: 44px !important;
  line-height: 44px !important;
  border-radius: 22px !important;
  background-color: #1A2B6D !important;
  color: #ffffff !important;
  font-size: 15px !important;
  font-weight: bold !important;
  border: none !important;
  cursor: pointer !important;
  margin: 0 auto !important;
  padding: 0 20px !important;
  text-align: center !important;
  float: none !important;
  transition: all 0.3s ease !important;
  box-shadow: 0 4px 10px rgba(26, 43, 109, 0.25) !important;
}

.login100-form-btn:hover,
.wrap-login100 .login100-form-btn:hover {
  background-color: #132053 !important;
  box-shadow: 0 6px 15px rgba(26, 43, 109, 0.35) !important;
}

/* Responsive Media Queries */
@media (max-width: 768px) {
  .header {
    padding: 8px 15px !important;
  }

  .header img {
    max-height: 40px !important;
  }

  .container-login100 {
    flex-direction: column !important;
    justify-content: flex-start !important;
    align-items: center !important;
    padding: 20px 15px 35px 15px !important;
    gap: 20px !important;
    min-height: auto !important;
  }

  .container-login100 .wrap-login100 {
    max-width: 100% !important;
    width: 100% !important;
    padding: 25px 20px 30px 20px !important;
    margin: 10px 0 !important;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06) !important;
  }

  #star {
    margin: 0 auto !important;
    width: 100% !important;
    max-width: 260px !important;
  }

  .logo-box img,
  .wrap-login100 .logo-box img {
    max-width: 200px !important;
  }

  .login100-form-btn,
  .wrap-login100 .login100-form-btn {
    max-width: 100% !important;
  }
}

@media (max-width: 480px) {
  .header {
    padding: 6px 12px !important;
  }

  .header img {
    max-height: 35px !important;
  }

  .container-login100 {
    padding: 15px 10px 25px 10px !important;
    gap: 15px !important;
  }

  .container-login100 .wrap-login100 {
    padding: 20px 15px 25px 15px !important;
    border-radius: 10px !important;
  }

  .logo-box {
    margin-bottom: 15px !important;
  }

  .logo-box img,
  .wrap-login100 .logo-box img {
    max-width: 180px !important;
  }

  .wrap-login100 .form-control,
  .wrap-login100 form input[type="text"],
  .wrap-login100 form input[type="password"],
  .wrap-login100 .login100-form1 .form-control {
    font-size: 16px !important; /* Prevents auto-zoom on iOS */
    height: 42px !important;
  }

  .wrap-login100 label,
  .wrap-login100 form label,
  .wrap-login100 .login100-form1 label {
    font-size: 12px !important;
  }

  .login100-form-btn,
  .wrap-login100 .login100-form-btn {
    height: 42px !important;
    font-size: 14px !important;
  }
}
</style>
</head>
<body>
<div class="header">
  <div><img src="images/wp_logo1.png" alt="Logo"></div>
</div>

	<div class="limiter">
		<div class="container-login100">
		<?php
		if($star_month == 1){
		?>
		<div id="star">
		<h4 style="color: #1A2B6D; text-align: center; margin-bottom: 15px;"><b><i class="fa fa-star" aria-hidden="true"></i> Star Of The Month <i class="fa fa-star" aria-hidden="true"></i></b></h4>
<div class="slider-container">
  <div class="slider">
  <?php
							$stmt_select="SELECT * from start_month";
	                  $rslt_rs= mysqli_query($conn,$stmt_select);

					 $x = 1;
			   while($row = mysqli_fetch_assoc($rslt_rs)) {
				   ?>

    <div class="slide">
<img src="star_images/<?php echo $row["image_path"]; ?>" alt="Image 1"  width="600" height="400">
<div class="desc">
  <div style="margin-top:5px;"><b><?php echo $row["name"]; ?></b></div>
  <div style="margin-top:10px;"><?php echo $row["designation"]; ?></div>
</div>
	</div>
     <?php $x++; } ?>
  </div>
</div>
  </div>
  <?php }?>

			<div class="wrap-login100" style="width: 100%; max-width: 380px; margin: 20px auto; padding: 35px 30px; box-sizing: border-box; background: #ffffff; border-radius: 12px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);">
				<div class="logo-box" style="text-align: center; margin: 0 0 25px 0; padding: 0; width: 100%;">
					<img src="images/hexa.png" alt="Logo" style="max-width: 200px; height: auto; display: block; margin: 0 auto;">
				</div>

                <div class="form-group login-error" style="text-align: center; margin: 0 0 15px 0; padding: 0; width: 100%;">
				  <font color="red" size="2">
				   <?php
				   if($login_errorr_cnt =='1')
				   echo $login_errorr;
			       else
				   echo $login_errorr;
				   ?>
				  </font>
				</div>
				<form class="login100-form1 validate-form" action="<?php echo $_SERVER['PHP_SELF']?>" method="post" style="width: 100%; margin: 0; padding: 0; display: block;">
					<div class="form-group" style="width: 100%; margin: 0 0 18px 0; padding: 0; clear: both;">
					  <label for="username" style="display: block; width: 100%; text-align: left; margin: 0 0 6px 0; padding: 0; font-size: 13px; font-weight: 600; color: #333;">Enter Login ID:</label>
					  <input type="text" class="form-control" name="username" id="username" placeholder="Enter username" style="display: block; width: 100% !important; max-width: 100% !important; min-width: 100% !important; height: 42px; margin: 0; padding: 8px 12px; box-sizing: border-box; border-radius: 6px; border: 1px solid #ced4da;">
					</div>
					<div class="form-group" style="width: 100%; margin: 0 0 18px 0; padding: 0; clear: both;">
					  <label for="pass" style="display: block; width: 100%; text-align: left; margin: 0 0 6px 0; padding: 0; font-size: 13px; font-weight: 600; color: #333;">Enter Password:</label>
					  <input class="form-control" type="password" name="pass" placeholder="Enter password" style="display: block; width: 100% !important; max-width: 100% !important; min-width: 100% !important; height: 42px; margin: 0; padding: 8px 12px; box-sizing: border-box; border-radius: 6px; border: 1px solid #ced4da;">
					</div>
					<div class="form-group" id="userWorkTypeDivId" style="display:none; width: 100%; margin: 0 0 18px 0; padding: 0; clear: both;">
						 <label for="campaign" style="display: block; width: 100%; text-align: left; margin: 0 0 6px 0; padding: 0; font-size: 13px; font-weight: 600; color: #333;">Campaign</label>
						 <select class="form-control select2" style="display: block; width: 100% !important; max-width: 100% !important; height: 38px; box-sizing: border-box;" name="userWorkType" id="userWorkType" autocomplete="off" onchange="campaignChange();">
						</select>
					</div>
					<div class="form-group" id="userWorkTypeIngroupDivId" style="display:none; width: 100%; margin: 0 0 18px 0; padding: 0; clear: both;">
						<label for="Ingroup" style="display: block; width: 100%; text-align: left; margin: 0 0 6px 0; padding: 0; font-size: 13px; font-weight: 600; color: #333;">Ingroup</label>
						<select class="form-control select2" style="display: block; width: 100% !important; max-width: 100% !important; min-height: 45px; box-sizing: border-box;" autocomplete="off" name="ingroup[]" id="ingroup" multiple>
						</select>
					</div>

					<div class="container-login100-form-btn1" style="width: 100%; display: flex; justify-content: center; align-items: center; text-align: center; margin: 24px 0 0 0; padding: 0;">
						<input type="submit" class="login100-form-btn" name="Submit" value="Login" style="display: inline-block; width: 100%; max-width: 200px; height: 44px; line-height: 44px; margin: 0 auto; text-align: center;">
					</div>
				</form>
			</div>
		</div>
	</div>


<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(document).ready(function() {
    var slideCount = $('.slide').length;
    var slideWidth = $('.slide').width();
    var sliderWidth = slideCount * slideWidth;

    $('.slider').css('width', sliderWidth);

    function autoplay() {
      $('.slider').animate({
        marginLeft: -slideWidth
      }, 1000, function() {
        $('.slider .slide:first').appendTo('.slider');
        $('.slider').css('marginLeft', 0);
      });
    }

    var autoplayInterval = setInterval(autoplay, 4000); // Change slide every 3 seconds

    // Pause autoplay on hover
    $('.slider-container').hover(function() {
      clearInterval(autoplayInterval);
    }, function() {
      autoplayInterval = setInterval(autoplay, 4000);
    });
  });
</script>
	<script>
		function checkUserLevelLogin(){
			
			var username = document.getElementById("username").value;
			
			//alert(username);
			
				  $.ajax({
			type: 'POST',
			url: "checkUserLevelLogin.php",
			data: {
				'username': username
			},
			success: function(result) {
				var res = result.split("=====");
				//alert(result);
				console.log(result);
		      if((res[0] == "display")){
						document.getElementById("userWorkTypeDivId").style.display ="block";
						document.getElementById('userWorkType').innerHTML=res[1];
						document.getElementById("userWorkType").required  =true;
						

						}
						else if(res[0] == 'No display'){
							document.getElementById("userWorkTypeDivId").style.display ="none";
							document.getElementById("userWorkType").required  =false;
							document.getElementById("userWorkTypeIngroupDivId").style.display ="none";
							document.getElementById("ingroup").required  =false;

						}
						 else if(res[0] == 'admin'){
							document.getElementById("userWorkTypeDivId").style.display ="none";
							document.getElementById("userWorkType").required  =false;
							document.getElementById("userWorkTypeIngroupDivId").style.display ="none";
							document.getElementById("ingroup").required  =false;
							document.getElementById("supportType").style.display ="none";
							document.getElementById("supportWorkType").required  =false;


						}
			}
		});
		}
		
		
	function campaignChange() {

    var campaign = document.getElementById("userWorkType").value;
    var username = document.getElementById("username").value;

    $.ajax({
        type: "POST",
        url: "campaigncheck.php",
        data: {
            campaign: campaign,
            username: username
        },
        success: function(result) {

            console.log(result);
            // alert(result); // remove in production

            var res = result.split("=====");

            if (res[0] == "display") {

                document.getElementById("userWorkTypeIngroupDivId").style.display = "block";
                document.getElementById("ingroup").innerHTML = res[1];
                document.getElementById("ingroup").required = true;

            } 
            else if (res[0] == "No display") {

                document.getElementById("userWorkTypeIngroupDivId").style.display = "none";
                document.getElementById("ingroup").required = false;

            }

        },
        error: function(xhr, status, error) {
            console.log("AJAX Error:", error);
        }
    });

}
		
		
	</script>

</body>
</html>
