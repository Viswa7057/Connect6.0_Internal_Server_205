<?php

session_start();

ini_set('memory_limit', '8192M');
ini_set('max_execution_time', '6000');

$loggedInuserName  = $_SESSION['username'];
$loggedInPassword  = $_SESSION['pass'];
$loggedInUserLevel = $_SESSION['user_level'];

/*echo "<br><br>";
echo "====>".$_SESSION['user_level'];
echo "<br><br>";
echo "====>".$_SESSION['username'];
echo "<br><br>";
echo "====>".$_SESSION['pass'];
die;
*/
if($loggedInuserName == '' && $loggedInPassword == '' ){
	header('Location:/haloocomConnect5/pages/Agent/connect5Login/index.php');
}
require_once("db_connect.php");

$stmt_select="SELECT * from features_settings";
	      $rslt_rs= mysqli_query($conn,$stmt_select);


			   while($row = mysqli_fetch_assoc($rslt_rs)) {
				  $incoming_did = $row["incoming_did"];
				  $incoming_ivr = $row["incoming_ivr"];
				  $predictive_dialing = $row["predictive_dialing"];
				  $userwise_dialing = $row["userwise_dialing"];
				  $voice_blast = $row["voice_blast"];
				  $announcement = $row["announcement"];
				  $star_month = $row["star_month"];
				  $dependant_dropdown = $row["dependant_dropdown"];
				  $feedback_ivr = $row["feedback_ivr"];
				  $phone_book = $row["phone_book"];
			   }
			   
$stmt_group="SELECT user_group from users where user_id='$loggedInuserName'";
			//echo $stmt_group;
			$rslt_group= mysqli_query($conn,$stmt_group);
	        $row_g= mysqli_fetch_row($rslt_group);
		    $user_group = $row_g[0];
			
			if($user_group == "ADMIN"){
				$sql_usergroup = "SELECT `group_id` FROM `user_group`";
				$sql_result = mysqli_query($conn,$sql_usergroup);
				$no_of_user_group = array();
				while($row = mysqli_fetch_array($sql_result)){
						$group_id = $row[0];
						array_push($no_of_user_group,$group_id);
				}
				foreach($no_of_user_group as $val){
							$UserGroup_list.= "'$val',";
					}
				$User_GroupList = rtrim($UserGroup_list, ',');
			}else {
				$User_GroupList = "'$user_group'";
			}

$stmt_select = "SELECT * FROM campaign WHERE user_group in ($User_GroupList)";
$rslt_rs = mysqli_query($conn, $stmt_select);
if (mysqli_num_rows($rslt_rs) > 0) {
$campaigns_id = [];

while ($row = mysqli_fetch_assoc($rslt_rs)) {
    $campaigns_id[] = $row["campaign_id"];
}

$campaign_id_str = implode("','", $campaigns_id);
}

if($_POST['campaign_download']){

$start_date = $_POST['fromdate'];
$end_date = $_POST['todate'];
$campaign = $_POST['campaign'];

$stmt_select_dow = "SELECT monitorfile from call_log where campaign='$campaign' AND dial_time >='$start_date 00:00:00' AND dial_time <='$end_date 23:59:59' AND monitorfile!='' and monitorfile not like '%.mp3.mp3%' order by id DESC";

                        $rslt_rs_dow = mysqli_query($conn, $stmt_select_dow);
               $audioFiles = array();
                        $x = 1;
                        while ($row_file = mysqli_fetch_assoc($rslt_rs_dow)) {
                          $monitorfile_dow = $row_file["monitorfile"];
						  $audio_file_dow = str_replace("mp3", "wav", $monitorfile_dow);
						   //$audioFiles[]= "../../../voicefiles/".$audio_file_dow;
						   $audioFiles[]= "/var/www/html/voicefiles/".$audio_file_dow;
	                      }

// Create a zip archive
$zip = new ZipArchive();
$zipFileName = 'audio_files.zip';
$zipFilePath = "/var/www/html/haloocomConnect5/pages/forms/".$zipFileName;
shell_exec("chmod 777 $zipFilePath");

if ($zip->open($zipFileName, ZipArchive::CREATE) === TRUE) {
    // Add audio files to the zip folder
  foreach ($audioFiles as $audioFile) {
        if (file_exists($audioFile)) {
        $zip->addFile($audioFile, basename($audioFile));
        }
    }


    $zip->close();

    // Set headers to force download the zip folder
    header('Content-Type: application/octetstream');
    header('Content-disposition: attachment; filename=' . $zipFileName);
    header('Content-Length: ' . filesize($zipFileName));
    readfile($zipFileName);

    // Delete the temporary zip file after download
    unlink($zipFileName);

    exit;
} else {
    echo 'Failed to create zip file';
}

}
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="../../plugins/daterangepicker/daterangepicker.css">
  <!-- iCheck for checkboxes and radio inputs
  <link rel="stylesheet" href="../../plugins/icheck-bootstrap/icheck-bootstrap.min.css"> -->
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="../../plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="../../plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="../../plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="../../plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Bootstrap4 Duallistbox -->
  <link rel="stylesheet" href="../../plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css">
  <!-- BS Stepper -->
  <link rel="stylesheet" href="../../plugins/bs-stepper/css/bs-stepper.min.css">
  <!-- dropzonejs -->
  <link rel="stylesheet" href="../../plugins/dropzone/min/dropzone.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <style>
    thead th,
    table.dataTable thead td {
      padding: 15px 18px !important;
      border-bottom: 1px solid #dee2e6 !important;
    }

    table.dataTable.no-footer {
      border-bottom: 1px solid #dee2e6 !important;
    }

    .dataTables_wrapper .dataTables_info {
      clear: both;
      float: left;
      padding: 10px !important;
      font-size: smaller !important;
    }

    .dataTables_wrapper .dataTables_paginate {
      float: right;
      text-align: right;
      padding: 10px !important;
      font-size: smaller !important;
    }

    .dataTables_wrapper .dataTables_length {
      float: left;
      padding: 10px !important;
      font-size: smaller !important;
    }

    .dataTables_wrapper .dataTables_filter {
      float: right;
      text-align: right;
      padding: 10px !important;
      font-size: smaller !important;
    }

    .dataTables_wrapper .dataTables_filter input {
      border: 1px solid #dee2e6 !important;
    }

    .dt-button-collection {
      margin-top: 2.5px !important;
      margin-bottom: 5px !important;
    }

    .button-container-trcb {
    display: flex;
    align-items: center;
    gap: 10px;
}


.transcribe-container{
  text-align: center;
    position: absolute;
    top: 4.8rem;
    left: 34rem;
    font-size: 1.2rem;

}

.bi-button{
  position: absolute;
    //top: 160%;
    left: 76%;
    background-color: #1A2B6D;
    color: white;
    z-index: 9;
    width: 8%;
    border-radius: 18px;
    height: 63%;
}
  </style>
  <script>
    $(document).ready(function() {
      sampleDiv_zoom.style.zoom = '80%';
      var scale = 'scale(1)';
      document.body.style.webkitTransform = scale; // Chrome, Opera, Safari
      document.body.style.msTransform = scale; // IE 9
      document.body.style.transform = scale; // General
    });

function voicefile(file){

		//alert(file);

                var modal = document.getElementById("myModal");

		document.getElementById("modal_value").innerHTML = "<span class='close' align='right' style='color:white;'>&times;</span><center><h1 style='color:white;font-weight:bold;'>VOICEFILE PLAY</h1><hr><br><audio controls id='myAudio'>  <source src='"+file+"' type='audio/ogg'></center>";

                var span = document.getElementsByClassName("close")[0];

                modal.style.display = "block";

                span.onclick = function() {
                        modal.style.display = "none";
                }
}

  </script>
</head>

<body class="hold-transition sidebar-mini" id="sampleDiv_zoom">
  <div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
      <!-- Left navbar links -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <a href="../../index.php" class="nav-link">Home</a>
        </li>

      </ul>

      <!-- Right navbar links -->
      <ul class="navbar-nav ml-auto">
        <!-- Navbar Search -->
        <li class="nav-item" style="display:none;">
          <a class="nav-link" data-widget="navbar-search" href="#" role="button">
            <i class="fas fa-search"></i>
          </a>
          <div class="navbar-search-block">
            <form class="form-inline">
              <div class="input-group input-group-sm">
                <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                  <button class="btn btn-navbar" type="submit">
                    <i class="fas fa-search"></i>
                  </button>
                  <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </li>

        <!-- Messages Dropdown Menu -->

        <!-- Notifications Dropdown Menu -->
<li>
	  <div style="color:white;margin-left:10px;"><img src="img/hexa.png" alt="Admin Logo" class="brand-image" width ="220px" height="65px"></div>
	  </li>

        <li class="nav-item">
          <a class="nav-link" data-widget="fullscreen" href="#" role="button">
            <i class="fas fa-expand-arrows-alt"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../../logout.php" title="Signout" role="button"><i class="fas fa-sign-out-alt" style="color:red;"></i></a>
        </li>
        <li class="nav-item" style="display:none;">
          <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
            <i class="fas fa-th-large"></i>
          </a>
        </li>
      </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: #1A2B6D; color:white;">
      <!-- Brand Logo -->
      <a href="../../index.php" class="brand-link" style="background-color: #1A2B6D; color:white;">
        <img src="../../dist/img/logo.png" alt="Admin Logo" class="brand-image" style="opacity: .8">
        <span class="brand-text font-weight-light" style="color:#1A2B6D;">Voice Recordings</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">
        <!-- Sidebar user (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="../../dist/img/voip.png" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="#" class="d-block" style="color:white;"><?php echo $loggedInuserName; ?></a>
          </div>
        </div>

        <!-- SidebarSearch Form -->
        <div class="form-inline" style="display:none;">
          <div class="input-group" data-widget="sidebar-search">
            <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
            <div class="input-group-append">
              <button class="btn btn-sidebar">
                <i class="fas fa-search fa-fw"></i>
              </button>
            </div>
          </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-tachometer-alt"></i>
                <p>
                  Dashboard
                  <i class="right fas fa-angle-left"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="../../index.php" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Overview</p>
                  </a>
                </li>


              </ul>
            </li>

          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Administration
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">

			  <?php if($loggedInUserLevel=="SuperAdmin" or $loggedInUserLevel=="TL"){ //Start SuperAdmin and TelephonyAdmin Access ?>
              <?php require_once("side_menu.php"); ?>
			  <?php } //End SuperAdmin Access ?>

        </ul>
        </nav>
        <!-- /.sidebar-menu -->
      </div>
      <!-- /.sidebar -->
    </aside>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Voice Recordings</h1>
            </div>

            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="../../index.php">Home</a></li>
                <li class="breadcrumb-item active">Voice Recordings</li>
              </ol>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="card-footer">

          </div>

          <!-- SELECT2 EXAMPLE -->
		  <div class="card-header">
			<form action ="<?php echo $_SERVER['PHP_SELF'] ?>" method ="POST">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			 <div class="form-group" style="display: inline-block;width: 15%;vertical-align: top;margin-right:7px;">
			 <label for="UserID">From Date:</label><input type="date" class="form-control" id="fromdate" name="fromdate" value="<?php echo date('Y-m-d'); ?>">
		    <label for="UserID">To Date:</label><input type="date" class="form-control" id="todate" name="todate" value="<?php echo date('Y-m-d'); ?>">
					</div>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <div class="form-group" style="display: inline-block;width: 15%;vertical-align: top;margin-right:7px;">
                                          <label> Select Campaign</label>
                                          <select class="form-control select2" style="width: 100%;" name="campaign[]" id="campaign" multiple>
                                                <option value="ALL" selected readonly>ALL Campaigns</option>
                                                <?php
                                $stmt_select="SELECT distinct campaign_id from campaign where active_camp='Y' and user_group in ($User_GroupList)";
                          $rslt_rs= mysqli_query($conn,$stmt_select);

                           while($row = mysqli_fetch_assoc($rslt_rs)) {
				   $campaign_id = $row['campaign_id'];
				   echo "<option value='$campaign_id'>$campaign_id</option>";
                                                          } ?>
                                          </select>
					</div>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

					<div class="form-group" style="display: inline-block;width: 10%;vertical-align: top;margin-right:7px;margin-top:30px;">
					<input type="submit" class="form-control" name="campaign_download" value="Bulk Download" style="background-color: #e68a00;color: #ffff;">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="submit" class="form-control" name="btn_campaign" value="Filter" style="background-color: #3CB371;color: #ffff;">
					</div>


					</form>
					</div>
          <div class="card card-default">
            <div class="card-header">
              <h3 class="card-title">Voice Recordings</h3>
<!--
              <button class="bi-button">
                <a href="bi/Bi_search/pages/dashboard.html" target="_blank" style="color: white;"> Advanced BI</a>
              </button>
-->
              <div class="transcribe-container">
              <p class="transcript-load" style="color: blue;display:none;">Please wait your voice file is getting transcribed</p>
      <p class="transcript success" style="color: green;display:none;">Transcription Complete! Click on transcript to view your Transcription</p>
      </div>



              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
                <button type="button" style="display:none;" class="btn btn-tool" data-card-widget="remove">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">

<!-- The Modal -->
<div id="myModal" class="modal" style="display: none; margin-left: 650px; margin-top: 100px;">

  <!-- Modal content -->
  <div class="modal-content" id="modal_value" style="width:40%; height:35%; background-color:#1A2B6D;">
    <span class="close" align="right">&times;</span>
  </div>

</div>

              <div class="row">
              <div class="row">
                <div class="col-md-12">
                  <div class="card-body p-0">
                    <table class="table table-striped projects table-bordered" id="table_camp">
                      <thead>
                        <tr>

                           <th>
						   S/No
						   </th>
                          <th>
                            Date Time
                          </th>
                          <th>
                            Phone Number
                          </th>
                          <th>
                            Agent
                          </th>
						  <th>
                            Campaign
                          </th>
                          <th>
                            Duration
                          </th>

                          <th>
                            Filename
                          </th>


                          <?php if ($loggedInUserLevel == "SuperAdmin" or $loggedInUserLevel == "TelephonyAdmin" or $loggedInUserLevel == "Supervisor") { ?>
                            <th>
                              ACTION
                            </th>
<!--
                            <th>
                              Transcription
                            </th>
-->
                          <?php } ?>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
					if($_POST['btn_campaign']){

	                     $start_date = $_POST['fromdate'];
				         $end_date = $_POST['todate'];

        $select_campaigns = $_POST['campaign'];
        if(count($select_campaigns)==1 && $select_campaigns[0]==="ALL")
        {
                $camp_stmt="SELECT distinct campaign_id from campaign where active_camp='Y' and user_group in ($User_GroupList)";
                $camp_rslt=mysqli_query($conn,$camp_stmt);
                while($camp_rows = mysqli_fetch_array($camp_rslt))
                {
                        $campaign_id=$camp_rows['campaign_id'];
                        $all_campaigns.=",".$campaign_id;
                }
                $campaigns = ltrim($all_campaigns, ",");
                $select_campaign = str_replace(",","','",$campaigns);
        }else{
		$select_campaign = implode("','", $select_campaigns);
        }

                        $stmt_select = "SELECT * from call_log where campaign in ('$select_campaign') AND dial_time >='$start_date 00:00:00' AND dial_time <='$end_date 23:59:59' order by id DESC";
			//echo $stmt_select;exit;
                        $rslt_rs = mysqli_query($conn, $stmt_select);

                        $x = 1;
                        while ($row = mysqli_fetch_assoc($rslt_rs)) {
							
                          $monitorfile = $row["monitorfile"];
                          $filenameWithoutExtension = pathinfo($monitorfile, PATHINFO_FILENAME);
                          $file_wav = $filenameWithoutExtension.".wav";
                          $transcriptionFilename = "transcriptions/" . $filenameWithoutExtension.".wav".".txt";

							if($row['client_duration'] == ""){
								$totalClientDuration = 0;
							}else{
								$totalClientDuration = $row['client_duration'];
							}
							$TotalClient_Time = gmdate("H:i:s", $totalClientDuration);
							
							$query_select = "SELECT `user_id` FROM `users` WHERE `extension_id`='".$row['agent']."'";
							$res_select = mysqli_query($conn,$query_select);
							$rowF = mysqli_fetch_array($res_select);
							$Agent_name = $rowF['user_id'];
						
						if($row["agent"]!='dddd'){

                        ?>
                          <tr>

						  <td>
                              <?php echo $x; ?>
                            </td>
                            <td>
                              <?php echo $row["dial_time"]; ?>
                            </td>
                            <td>
                              <a>
                                <?php echo $row["calledid"]; ?>
                              </a>
                            </td>
                            <td>
                              <?php echo $Agent_name; ?>
                            </td>
							<td>
                              <?php echo $row["campaign"]; ?>
                            </td>
                            <td>
                              <?php echo $TotalClient_Time; ?>
                            </td>
                            <td>
                              <?php echo $row["monitorfile"]; ?>
                            </td>



                            <?php if ($loggedInUserLevel == "SuperAdmin" or $loggedInUserLevel == "TelephonyAdmin" or $loggedInUserLevel == "Supervisor") { ?>
                              <td class="project-actions text-right">

                                <?php

                                $audio_file = str_replace("mp3", "wav", $row["monitorfile"]);
                                ?>


                                <span class="btn btn-info btn-sm">
                                  <a href="<?php echo "$incoming_api/voicefiles/".$audio_file; ?>" style="color:white;" target="_blank">

                                    <i class="fa fa-play">
                                    </i>
                                    Play
                                  </a>
                                </span>


                                <span class="btn btn-success btn-sm"><a href="voice_download.php?link=<?php echo $audio_file; ?>" style="color:white;">
                                    <i class="fa fa-download">
                                    </i>
                                    Download
                                  </a>
                                </span>

                              </td>
<!--
                              <td>
                                <div class="button-container-trcb">
                                  <button data-src='<?php echo $file_wav; ?>' class='btn return-button' onclick='sendData(this)' style="background-color: darkturquoise;"><span class="btn-text"><i class="fas fa-microphone-alt-slash"></i>Transcribe</span></button>
                                  <button data-src='<?php echo $transcriptionFilename; ?>' class='btn open-transcription' onclick='openTranscription(this)' style="background-color: bisque; display: <?php echo $row["transcription"] == 'yes' ? 'block' : 'none'; ?>;"> <span class="btn-text"><i class="fas fa-scroll"></i>Transcript</span></button>
                                </div>
                              </td>
-->
                            <?php } ?>
                          </tr>

                        <?php $x++;
					}}
					}else{
						 // $stmt_select="SELECT * from call_log where monitorfile LIKE'OUT%' OR monitorfile LIKE'INC%'";
						 $today = date("Y-m-d");
                        $stmt_select = "SELECT dial_time,calledid,agent,campaign,monitorfile,client_duration,transcription from call_log where campaign IN ('$campaign_id_str') AND agent!='' AND campaign!='' AND calledid!='' AND dial_time >='$today 00:00:00' AND dial_time <='$today 23:59:59' order by id DESC";

						//echo $stmt_select; exit;
                        $rslt_rs = mysqli_query($conn, $stmt_select);

                  if (mysqli_num_rows($rslt_rs) > 0) {
                        $x = 1;
                        while ($row = mysqli_fetch_assoc($rslt_rs)) {
                          $monitorfile = $row["monitorfile"];
                          $filenameWithoutExtension = pathinfo($monitorfile, PATHINFO_FILENAME);
                          $file_wav = $filenameWithoutExtension.".wav";
                          $transcriptionFilename = "transcriptions/" . $filenameWithoutExtension.".wav".".txt";

					if($row['client_duration'] == "" || $row['client_duration'] == "3020399"){
						$totalClientDuration = 0;
					}else{
						$totalClientDuration = $row['client_duration'];
					}
					$TotalClient_Time = gmdate("H:i:s", $totalClientDuration);
					
					        $query_select = "SELECT `user_id` FROM `users` WHERE `extension_id`='".$row['agent']."'";
							$res_select = mysqli_query($conn,$query_select);
							$rowF = mysqli_fetch_array($res_select);
							$Agent_name = $rowF['user_id'];
							
					if($row["agent"]!='dddd'){
                        ?>
                          <tr>

						  <td>
                              <?php echo $x; ?>
                            </td>
                            <td>
                              <?php echo $row["dial_time"]; ?>
                            </td>
                            <td>
                              <a>
                                <?php echo $row["calledid"]; ?>
                              </a>
                            </td>
                            <td>
                              <?php echo $Agent_name; ?>
                            </td>
							<td>
                              <?php echo $row["campaign"]; ?>
                            </td>
                            <td>
                              <?php echo $TotalClient_Time; ?>
                            </td>
                            <td>
                              <?php echo $row["monitorfile"]; ?>
                            </td>



                            <?php if ($loggedInUserLevel == "SuperAdmin" or $loggedInUserLevel == "TelephonyAdmin" or $loggedInUserLevel == "Supervisor") { ?>
                              <td class="project-actions text-right">

                                <?php

                                $audio_file = str_replace("mp3", "wav", $row["monitorfile"]);
				$voice_file = "$incoming_api/voicefiles/".$audio_file;
                                ?>


					<button class="btn btn-info btn-sm" onclick="return voicefile('<?php echo $voice_file; ?>');"><i class="fa fa-play">
                                    </i>
                                    Play</button>



                                <span class="btn btn-success btn-sm"><a href="voice_download.php?link=<?php echo $audio_file; ?>" style="color:white;">
                                    <i class="fa fa-download">
                                    </i>
                                    Download
                                  </a>
                                </span>

                              </td>
<!--
                              <td>
                                <div class="button-container-trcb">
                                  <button data-src='<?php echo $file_wav; ?>' class='btn return-button' onclick='sendData(this)' style="background-color: darkturquoise;"><span class="btn-text"><i class="fas fa-microphone-alt-slash"></i>Transcribe</span></button>
                                  <button data-src='<?php echo $transcriptionFilename; ?>' class='btn open-transcription' onclick='openTranscription(this)' style="background-color: bisque; display: <?php echo $row["transcription"] == 'yes' ? 'block' : 'none'; ?>;"> <span class="btn-text"><i class="fas fa-scroll"></i>Transcript</span></button>
                                </div>
                              </td>
-->
                            <?php } ?>
                          </tr>

                        <?php $x++;
                        }}
					}
					}
					?>
                      </tbody>
                    </table>
                  </div>
                  <!-- /.form-group -->
                </div>
                <!-- /.col -->

                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- /.row -->
            </div>
            <!-- /.card-body -->

          </div>
          <!-- /.card -->

          <!-- The Modal -->


          <!-- /.row -->

          <!-- The Modal Edit -->

          <!-- /.row -->

          <!-- The Modal Delete-->

          <!-- /.row -->

        </div>
        <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
      <div class="float-right d-none d-sm-block">
        <b>Version</b> 6.0
      </div>
      <strong>Copyright &copy; Haloocom Technologies All rights reserved.
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->


  <!-- Bootstrap 4 -->
  <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Select2 -->
  <script src="../../plugins/select2/js/select2.full.min.js"></script>
  <!-- Bootstrap4 Duallistbox -->
  <script src="../../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
  <!-- InputMask -->
  <script src="../../plugins/moment/moment.min.js"></script>

  <!-- date-range-picker -->
  <script src="../../plugins/daterangepicker/daterangepicker.js"></script>
  <!-- bootstrap color picker -->
  <script src="../../plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="../../plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Bootstrap Switch -->
  <script src="../../plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
  <!-- BS-Stepper -->
  <script src="../../plugins/bs-stepper/js/bs-stepper.min.js"></script>
  <!-- dropzonejs -->
  <script src="../../plugins/dropzone/min/dropzone.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../../dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <!--<script src="../../dist/js/demo.js"></script> -->
  <!-- Page specific script -->
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">

  <script>


   function sendData(button) {
    var dataSrc = button.getAttribute('data-src');
    var $transcriptLoad = $('.transcript-load');
    var $transcriptSuccess = $('.transcript.success');
    var $btnText = $(button).find('.btn-text');

    $btnText.html('<i class="fas fa-spinner fa-spin"></i>Transcribing...');
    $transcriptLoad.fadeIn();


    fetch('http://18.141.112.242:5000/download', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'data_src=' + encodeURIComponent(dataSrc)
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);

        fetch('update_transcription_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'data_src=' + encodeURIComponent(dataSrc)
        })
        .then(response => response.json())
        .then(updateData => {
            console.log(updateData);

            if (updateData.message === "Transcribed status updated successfully") {
              $transcriptLoad.fadeOut(function() {
                    $transcriptSuccess.fadeIn();
                    setTimeout(function() {
                        $transcriptSuccess.fadeOut();
                    }, 3000);
                });

              $btnText.html('<i class="fas fa-microphone-alt-slash"></i>Transcribe');

                var $openTranscriptionBtn = $(button).closest('td').find('.open-transcription');
                $openTranscriptionBtn.show();
            }
        })
        .catch(error => {
            console.error('Error updating transcribed status:', error);
        });
    })
    .catch(error => {
        console.error('Error:', error);
    });
}



    function openTranscription(button) {
      const dataSrc = button.getAttribute('data-src');

      window.open(dataSrc, '_blank');
    }



    function downloadClick(link) {

      alert(link);
      $.ajax({
        type: 'POST',
        url: "voice_download.php",
        data: {
          'link': link
        },
        success: function(result) {

          alert(result);


        }
      });
    }
  </script>
  <script>
    $(function() {

      $('#table_camp').dataTable();

      //Initialize Select2 Elements

      $(function() {
        $("#phone_name").change(function() {
          if ($(this).val() == "Local") {
            $("#dvPhoneNo").show();
          } else {
            $("#dvPhoneNo").hide();
          }
        });

        $("#txt_phone_name").change(function() {
          if ($(this).val() == "Local") {
            $("#txt_dvPhoneNo").show();
          } else {
            $("#txt_dvPhoneNo").hide();
            document.getElementById('txt_Phone_no').value = "";
          }
        });

      });

      $('.select2').select2()

      //Initialize Select2 Elements
      $('.select2bs4').select2({
        theme: 'bootstrap4'
      })

      //Datemask dd/mm/yyyy
      $('#datemask').inputmask('dd/mm/yyyy', {
        'placeholder': 'dd/mm/yyyy'
      })
      //Datemask2 mm/dd/yyyy
      $('#datemask2').inputmask('mm/dd/yyyy', {
        'placeholder': 'mm/dd/yyyy'
      })
      //Money Euro
      $('[data-mask]').inputmask()

      //Date picker
      $('#reservationdate').datetimepicker({
        format: 'L'
      });

      //Date and time picker
      $('#reservationdatetime').datetimepicker({
        icons: {
          time: 'far fa-clock'
        }
      });

      //Date range picker
      $('#reservation').daterangepicker()
      //Date range picker with time picker
      $('#reservationtime').daterangepicker({
        timePicker: true,
        timePickerIncrement: 30,
        locale: {
          format: 'MM/DD/YYYY hh:mm A'
        }
      })
      //Date range as a button
      $('#daterange-btn').daterangepicker({
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function(start, end) {
          $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
        }
      )

      //Timepicker
      $('#timepicker').datetimepicker({
        format: 'LT'
      })

      //Bootstrap Duallistbox
      $('.duallistbox').bootstrapDualListbox()

      //Colorpicker
      $('.my-colorpicker1').colorpicker()
      //color picker with addon
      $('.my-colorpicker2').colorpicker()

      $('.my-colorpicker2').on('colorpickerChange', function(event) {
        $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
      })

      $("input[data-bootstrap-switch]").each(function() {
        $(this).bootstrapSwitch('state', $(this).prop('checked'));
      })

    })
    // BS-Stepper Init
    document.addEventListener('DOMContentLoaded', function() {
      window.stepper = new Stepper(document.querySelector('.bs-stepper'))
    })

    // DropzoneJS Demo Code Start
    Dropzone.autoDiscover = false

    // Get the template HTML and remove it from the doumenthe template HTML and remove it from the doument
    var previewNode = document.querySelector("#template")
    previewNode.id = ""
    var previewTemplate = previewNode.parentNode.innerHTML
    previewNode.parentNode.removeChild(previewNode)

    var myDropzone = new Dropzone(document.body, { // Make the whole body a dropzone
      url: "/target-url", // Set the url
      thumbnailWidth: 80,
      thumbnailHeight: 80,
      parallelUploads: 20,
      previewTemplate: previewTemplate,
      autoQueue: false, // Make sure the files aren't queued until manually added
      previewsContainer: "#previews", // Define the container to display the previews
      clickable: ".fileinput-button" // Define the element that should be used as click trigger to select files.
    })

    myDropzone.on("addedfile", function(file) {
      // Hookup the start button
      file.previewElement.querySelector(".start").onclick = function() {
        myDropzone.enqueueFile(file)
      }
    })

    // Update the total progress bar
    myDropzone.on("totaluploadprogress", function(progress) {
      document.querySelector("#total-progress .progress-bar").style.width = progress + "%"
    })

    myDropzone.on("sending", function(file) {
      // Show the total progress bar when upload starts
      document.querySelector("#total-progress").style.opacity = "1"
      // And disable the start button
      file.previewElement.querySelector(".start").setAttribute("disabled", "disabled")
    })

    // Hide the total progress bar when nothing's uploading anymore
    myDropzone.on("queuecomplete", function(progress) {
      document.querySelector("#total-progress").style.opacity = "0"
    })

    // Setup the buttons for all transfers
    // The "add files" button doesn't need to be setup because the config
    // `clickable` has already been specified.
    document.querySelector("#actions .start").onclick = function() {
      myDropzone.enqueueFiles(myDropzone.getFilesWithStatus(Dropzone.ADDED))
    }
    document.querySelector("#actions .cancel").onclick = function() {
      myDropzone.removeAllFiles(true)
    }
    // DropzoneJS Demo Code End



    function phoneEditFun(val) {
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          //alert(this.responseText);
          var val = this.responseText;
          var res = val.split("*");

          //alert(res);
          document.getElementById('txt_phone_id').value = res[0];
          document.getElementById('txt_Phone_Password').value = res[1];
          document.getElementById('txt_id').value = res[2];
        }
      };
      xhttp.open("GET", "/haloocomConnect5/pages/Agent_mongodb/ajax/get_phoneedit_data.php?id=" + val, true);
      xhttp.send();
      // Get the modal
      var modal1 = document.getElementById('myModal_edit');
      // Get the button that opens the modal
      var btn1 = document.getElementById("myBtngrpedit");
      // Get the <span> element that closes the modal
      var span1 = document.getElementsByClassName("close1")[0];
      // When the user clicks the edit button, open the modal
      modal1.style.display = "block";
      // When the user clicks on <span> (x), close the modal
      span1.onclick = function() {

        modal1.style.display = "none";
      }
      // When the user clicks anywhere outside of the modal, close it
      window.onclick = function(event) {
        if (event.target == modal1) {
          modal1.style.display = "none";
        }
      }

    }


    function phoneDeleteFun(val_grpd, PhoneIDVal) {
      document.getElementById('deletePhoneID').value = val_grpd;
      document.getElementById('txt_deletePhone_id').value = PhoneIDVal;

      // Get the modal
      var modal2 = document.getElementById('myModal_delete');

      // Get the button that opens the modal
      var btn2 = document.getElementById("myBtn2");

      // Get the <span> element that closes the modal
      var span2 = document.getElementsByClassName("close23")[0];

      // When the user clicks the edit button, open the modal
      modal2.style.display = "block";

      // When the user clicks on <span> (x), close the modal
      span2.onclick = function() {
        modal2.style.display = "none";
      }
      // When the user clicks anywhere outside of the modal, close it
      window.onclick = function(event) {
        if (event.target == modal2) {
          modal2.style.display = "none";
        }
      }


    }
  </script>
</body>

</html>
