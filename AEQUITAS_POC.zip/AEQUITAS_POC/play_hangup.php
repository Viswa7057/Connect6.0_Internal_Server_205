<?php
require_once("db_connect.php");

$user = $_REQUEST['user'];
$campaign = $_REQUEST['campaign'];

$stmt_select = "select play_hangup_file from user_live where user='$user' and campaign='$campaign';";
$rslt_select = mysqli_query($conn,$stmt_select);
$row_count = mysqli_num_rows($rslt_select);
if($row_count>0)
{
  $rows = mysqli_fetch_array($rslt_select);
  $play_hangup_file = $rows['play_hangup_file'];
  echo $play_hangup_file;

  $stmt_update_live = "update user_live set play_hangup_file='Yes' where user='$user' and campaign='$campaign';";
  $rslt_update_live = mysqli_query($conn,$stmt_update_live);

}

?>
