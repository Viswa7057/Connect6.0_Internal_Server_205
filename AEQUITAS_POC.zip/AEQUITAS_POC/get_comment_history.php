<?php

require_once("db_connect.php");

$phoneNumber = $_POST['phone_number'] ?? '';

$phoneNumber = trim($phoneNumber);

if ($phoneNumber == '') {
    echo '<div class="alert alert-warning">Phone number is required.</div>';
    exit;
}

// Escape phone number
$phoneNumber = mysqli_real_escape_string($conn, $phoneNumber);

$sql = "SELECT dial_time, comments
        FROM call_log
        WHERE calledid = '$phoneNumber'
        ORDER BY dial_time DESC limit 10";

$result = mysqli_query($conn, $sql);

if (!$result) {
    echo '<div class="alert alert-danger">Database error.</div>';
    exit;
}

if (mysqli_num_rows($result) == 0) {
    echo '<div class="alert alert-info">No comment history found.</div>';
    exit;
}

echo '<div class="table-responsive">';
echo '<table class="table table-bordered table-hover">';
echo '<thead>';
echo '<tr>';
echo '<th style="width:200px;">Dial Time</th>';
echo '<th>Comments</th>';
echo '</tr>';
echo '</thead>';
echo '<tbody>';

while ($row = mysqli_fetch_assoc($result)) {

    $dialTime = htmlspecialchars($row['dial_time'] ?? '');
    $comments = htmlspecialchars($row['comments'] ?? '');

    echo '<tr>';
    echo '<td>' . $dialTime . '</td>';
    echo '<td>' . nl2br($comments) . '</td>';
    echo '</tr>';
}

echo '</tbody>';
echo '</table>';
echo '</div>';
?>