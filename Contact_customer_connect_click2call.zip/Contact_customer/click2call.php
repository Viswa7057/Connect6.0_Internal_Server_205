
<?php
date_default_timezone_set("Asia/Kolkata");
header("Content-Type: application/json");

//require_once __DIR__ . "/dbconnect.php";
$conn = new mysqli("localhost", "root", "Hal0o(0m@72427242", "asterisk");
/* Configure using your dedicated AMI credentials */
define("AMI_HOST", "127.0.0.1");
define("AMI_PORT", 5038);
define("AMI_USER", "customclickapi");
define("AMI_SECRET", "1234");

function response($code, $message, $data = null) {
    http_response_code($code);
    echo json_encode([
        "status_code" => $code,
        "message" => $message,
        "data" => $data
    ]);
    exit;
}

function amiConnect() {
    $errno = 0;
    $errstr = "";

    $fp = fsockopen(
        AMI_HOST,
        AMI_PORT,
        $errno,
        $errstr,
        5
    );

    if (!$fp) {
        throw new Exception("AMI connection failed");
    }

    stream_set_timeout($fp, 5);

    // Read AMI greeting
    fgets($fp, 4096);

    return $fp;
}
function amiAction($fp, array $headers) {
    foreach ($headers as $key => $value) {
        fwrite($fp, "$key: $value\r\n");
    }
    fwrite($fp, "\r\n");
    fflush($fp);

    $result = [];
    while (($line = fgets($fp, 4096)) !== false) {
        $line = trim($line);
        if ($line === "") continue;
        if (strpos($line, ":") !== false) {
            [$key, $value] = explode(":", $line, 2);
            $result[trim($key)] = trim($value);
        }
        // Stop only when we see both Response and Message
        if (isset($result["Response"]) && isset($result["Message"])) break;
    }
    return $result;
}

$fp = null;

try {
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        response(405, "Use POST");
    }

    $ext = trim($_POST["extension"] ?? "");
    $mobile = preg_replace('/\D/', '', $_POST["mobile"] ?? "");

    if (!preg_match('/^[0-9]{1,10}$/', $ext)) {
        response(400, "Invalid extension");
    }

    if (!preg_match('/^[0-9]{10,15}$/', $mobile)) {
        response(400, "Invalid mobile number");
    }

    $callId = bin2hex(random_bytes(16));
    $recording = "/var/spool/asterisk/monitor/custom/" .
                 $callId . ".wav";

    $stmt = $conn->prepare("
        INSERT INTO custom_click2call_logs
        (unique_id, agent_extension, mobile_number,
         call_status, recording_file)
        VALUES (?, ?, ?, 'INITIATED', ?)
    ");

    $stmt->bind_param(
        "ssss",
        $callId,
        $ext,
        $mobile,
        $recording
    );

    if (!$stmt->execute()) {
        throw new Exception("Database insert failed");
    }
    $stmt->close();

    $fp = amiConnect();

    $login = amiAction($fp, [
        "Action" => "Login",
        "Username" => AMI_USER,
        "Secret" => AMI_SECRET,
        "Events" => "off"
    ]);

    if (($login["Response"] ?? "") !== "Success") {
        throw new Exception("AMI authentication failed");
    }

   $originate = amiAction($fp, [
    "Action"   => "Originate",
    "ActionID" => $callId,
    "Channel"  => "SIP/" . $ext,
    "Context"  => "custom-click2call",
    "Exten"    => "s",
    "Priority" => "1",
    "Timeout"  => "30000",
    "CallerID" => "Click2Call <" . $ext . ">",
    "Async"    => "true",
    "Variable" => "CALL_ID=$callId,AGENT_EXT=$ext,MOBILE=$mobile"
]);

    if (($originate["Response"] ?? "") !== "Success") {
        $stmt = $conn->prepare("
            UPDATE custom_click2call_logs
            SET call_status = 'ORIGINATE_FAILED'
            WHERE unique_id = ?
        ");
        $stmt->bind_param("s", $callId);
        $stmt->execute();
        $stmt->close();

        throw new Exception(
            $originate["Message"] ?? "Originate failed"
        );
    }

    $stmt = $conn->prepare("
        UPDATE custom_click2call_logs
        SET call_status = 'AGENT_RINGING'
        WHERE unique_id = ?
    ");
    $stmt->bind_param("s", $callId);
    $stmt->execute();
    $stmt->close();

    response(200, "Call originate accepted", [
        "unique_id" => $callId,
        "extension" => $ext,
        "mobile" => $mobile,
        "status" => "AGENT_RINGING"
    ]);

} catch (Throwable $e) {
    error_log("Click2Call error: " . $e->getMessage());
    response(500, "Click2Call failed; check server logs");
} finally {
    if (is_resource($fp)) {
        @fwrite($fp, "Action: Logoff\r\n\r\n");
        @fclose($fp);
    }
}
?>
