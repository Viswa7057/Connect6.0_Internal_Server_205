<?php
date_default_timezone_set("Asia/Kolkata");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "Hal0o(0m@72427242", "asterisk");

function respond($code, $message, $data = null) {
    http_response_code($code);
    echo json_encode([
        "status_code" => $code,
        "message" => $message,
        "data" => $data
    ]);
    exit;
}

define("AMI_HOST", "127.0.0.1");
define("AMI_PORT", 5038);
define("AMI_USER", "customclickapi");
define("AMI_SECRET", "1234");

$callId = trim($_POST["unique_id"] ?? "");
if (!preg_match('/^[a-f0-9]{32}$/', $callId)) {
    respond(400, "Invalid unique ID");
}

$stmt = $conn->prepare("
    SELECT agent_channel, call_status
    FROM custom_click2call_logs
    WHERE unique_id = ?
    LIMIT 1
");
$stmt->bind_param("s", $callId);
$stmt->execute();
$stmt->bind_result($channel, $status);
if (!$stmt->fetch()) {
    $stmt->close();
    respond(404, "Call not found");
}
$stmt->close();

if (in_array($status, ["COMPLETED", "NOT_ANSWERED", "ENDED"], true)) {
    respond(409, "Call has already ended");
}
if (empty($channel)) {
    respond(409, "Agent channel is not available yet");
}

try {
    $fp = fsockopen(AMI_HOST, AMI_PORT, $errno, $errstr, 5);
    if (!$fp) {
        throw new Exception("AMI connection failed: $errstr");
    }
    fgets($fp, 4096); // greeting

    fwrite($fp, "Action: Login\r\nUsername: " . AMI_USER . "\r\nSecret: " . AMI_SECRET . "\r\nEvents: off\r\n\r\n");
    fwrite($fp, "Action: Hangup\r\nChannel: " . $channel . "\r\n\r\n");
    fwrite($fp, "Action: Logoff\r\n\r\n");
    fclose($fp);

    $stmt = $conn->prepare("
        UPDATE custom_click2call_logs
        SET hangup_by = 'API',
            call_status = 'HANGUP_REQUESTED'
        WHERE unique_id = ?
          AND end_time IS NULL
    ");
    $stmt->bind_param("s", $callId);
    $stmt->execute();
    $stmt->close();

    respond(200, "Hangup requested", ["unique_id" => $callId]);

} catch (Throwable $e) {
    respond(500, "Hangup command failed", ["details" => $e->getMessage()]);
}
?>
