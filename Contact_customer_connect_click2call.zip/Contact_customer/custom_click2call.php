#!/usr/bin/php -q
<?php
date_default_timezone_set("Asia/Kolkata");

/*
 * Replace these values with your existing database credentials.
 * Do not expose this file through the web server.
 */
$db = new mysqli("localhost", "root", "Hal0o(0m@72427242", "asterisk");

if ($db->connect_error) {
    exit(1);
}

$env = [];

while (($line = fgets(STDIN)) !== false) {
    $line = trim($line);
    if ($line === "") {
        break;
    }

    if (strpos($line, ": ") !== false) {
        [$key, $value] = explode(": ", $line, 2);
        $env[$key] = $value;
    }
}

$action = $argv[1] ?? "";
$callId = $argv[2] ?? "";

if (!preg_match('/^[a-f0-9]{32}$/', $callId)) {
    exit(1);
}

function agiSet($value) {
    echo "SET VARIABLE AGI_RESULT " . $value . "\n";
    fflush(STDOUT);
}

if ($action === "start") {
    $ext = $argv[3] ?? "";
    $mobile = $argv[4] ?? "";
    $channel = $env["agi_channel"] ?? "";

    $stmt = $db->prepare("
        UPDATE custom_click2call_logs
        SET agent_channel = ?,
            call_status = 'AGENT_CONNECTED',
            start_time = NOW()
        WHERE unique_id = ?
    ");

    $stmt->bind_param("ss", $channel, $callId);
    $stmt->execute();
    $stmt->close();

} elseif ($action === "end") {
    $status = $argv[3] ?? "UNKNOWN";
    $answered = (int)($argv[4] ?? 0);
    $cause = $argv[5] ?? "";
    $recording = $argv[6] ?? "";

    $callStatus = $answered > 0 ? "COMPLETED" : "NOT_ANSWERED";

    $stmt = $db->prepare("
        UPDATE custom_click2call_logs
        SET call_status = ?,
            answer_time = IF(? > 0,
                DATE_ADD(start_time, INTERVAL 0 SECOND), answer_time),
            end_time = NOW(),
            duration_seconds = ?,
            hangup_cause = ?,
            recording_file = ?
        WHERE unique_id = ?
    ");

    $stmt->bind_param(
        "siisss",
        $callStatus,
        $answered,
        $answered,
        $cause,
        $recording,
        $callId
    );

    $stmt->execute();
    $stmt->close();

} elseif ($action === "hangup") {
    $status = $argv[3] ?? "UNKNOWN";
    $cause = $argv[4] ?? "";

    $stmt = $db->prepare("
        UPDATE custom_click2call_logs
        SET end_time = COALESCE(end_time, NOW()),
            duration_seconds = TIMESTAMPDIFF(
            SECOND,
            start_time,
            COALESCE(end_time, NOW())
        ),
            hangup_cause = ?,
            call_status = IF(call_status IN
                ('COMPLETED','NOT_ANSWERED'), call_status, 'ENDED')
        WHERE unique_id = ?
    ");

    $stmt->bind_param("ss", $cause, $callId);
    $stmt->execute();
    $stmt->close();
}

$db->close();
exit(0);
?>
